# SCHMAQQ Studio Seiten und Abläufe

Stand: 24.10.2026 · Version 1 · Statischer Bedienentwurf für Marco und Markus

Dieser Entwurf übersetzt das Gesamtproduktkonzept V2 in konkrete Seiten, Texte und Übergänge. Alle genannten Erfolgsanzeigen sind beispielhafte Sollzustände. Funktionsverfügbarkeit, tatsächliche Speicherwirkung und Anfängerfreundlichkeit sind UNVERIFIED, solange sie nicht am späteren Produkt geprüft wurden. Es gibt keine Code- oder Betriebsfreigabe.

## 1 Navigation und wiederkehrender Aufbau

Persönlicher Arbeitsplatz: **Start · Projekte · Für mich · Zusammenarbeit**. Profil, persönliche Verbindungen und Hilfe sind dauerhaft erreichbar. „Für mich“ enthält eigene Aufgaben, direkte Fragen und angefragte Prüfungen; Lesen allein erledigt keinen Auftrag.

Im Projekt: **Überblick · Plan & Aufgaben · Austausch · Wissen · Ergebnisse**. Der Projektkopf nennt Projekt, Mitglieder und Zugang zur Einrichtung. Einladen ist projektbezogen. Einrichtungsprobleme erscheinen außerdem bei der betroffenen Handlung.

Jede Arbeitsansicht beantwortet in dieser Reihenfolge: Wo bin ich? Was ist der aktuelle Stand? Wer ist dran? Was mache ich als Nächstes? Vertiefende Herkunft, technische Details und Verlauf folgen darunter.

Start und Projektüberblick haben jeweils eine führende Fortsetzen-Aktion. Die anderen Aktionen bleiben visuell nachgeordnet. Breadcrumb und Browser-Zurück erhalten Projekt, Filter und Arbeitsstelle. Die statischen mobilen Ansichten zeigen eine kompakte beschriftete Navigation im Kopf; eine einklappbare Variante bleibt eine spätere Option. Aufgaben werden standardmäßig als Liste gezeigt.

Speicheranzeigen unterscheiden **Entwurf nur auf diesem Gerät**, **Wird gespeichert**, **Gespeichert** und **Nicht gespeichert**. „Gespeichert“ verlangt eine bestätigte Speicherung und bezeichnet noch keinen Commit oder GitHub-Stand. Eine fehlgeschlagene Eingabe bleibt sichtbar und kopierbar.

## 2 Bildschirmverzeichnis

| ID | Ansicht und sichtbarer Inhalt | Hauptaktion → Ziel | Nebenaktion und Speicherwirkung |
| --- | --- | --- | --- |
| S01 | Start bei Rückkehr: gespeicherter Formularentwurf, nächste Prüfung, Rückfrage und Projekte | „Meine Arbeit fortsetzen“ → A01 | „Aufgabe ansehen“ → A01; keine Schreibwirkung beim Öffnen |
| S02 | Start ohne Projekt: neue Idee und vorhandenes Projekt | „Neue Idee starten“ → N01 | „Bestehendes Projekt wählen“ → B01; keine Anlage durch bloße Auswahl |
| N01 | Vorhaben: Name und gewünschter Nutzen für die Zielgruppe | „Weiter: erste Version“ → N02 | „Entwurf speichern & später weiter“ → S01 mit Entwurfsvariante; Entwurf nur für dich sichtbar |
| N02 | Erste Version: begrenztes Ergebnis, Abnahmekriterium, Ideen für später | „Projekt mit erster Aufgabe anlegen“ → N03 | „Zurück zum Vorhaben“ → N01, Felder erhalten; einmalige Anlage erst nach Bestätigung |
| N03 | Projekt angelegt, Aufgabe „Buchungsformular fertigstellen“; zuerst Ablauf planen | „Erste Aufgabe öffnen“ → Aufgabenbeginn, noch nicht der spätere Stand A01 | „Markus dazuholen“ → Z01; „Einrichtung ansehen“ → E01; Ziel und spätere Ideen gespeichert |
| P01 | Projektüberblick nach gespeicherter Bearbeitung: Ziel, erste Etappe, nächster Schritt und letzte Änderung | „Meine Arbeit fortsetzen“ → A01 | „Mitglieder & Einladen“ → Z01, „Einrichtung“ → E01; Öffnen verändert keinen Arbeitsstand |
| B01 | Bestand wählen: bereits angeschlossenes Projekt oder weiteres unterstütztes Repository | „Bestand prüfen“ → B02, falls eigenes Gerät bereit | „Gerät einrichten“ → E01; Quellenauswahl als Entwurf, kein Überschreiben |
| B02 | Bestandsaufnahme mit erkanntem Projekt, zwei lokalen Änderungen und Feld für das nächste Ziel | „Mit dieser Aufgabe weiter“ → Aufgabe im vorhandenen Projekt | „Projektzuordnung korrigieren“ → B01; kein N02-Neustart und keine erneute Projektanlage |
| E01 | Persönliches Windows-Gerät: Einrichtungsplan, manuelle lokale Anleitung und anschließende echte Prüfung | „Einrichtungsplan herunterladen“ → lokale Anleitung außerhalb der Ansicht | „Später an dieser Stelle fortsetzen“; vorhandene Profile erhalten; noch keine Verbindung bestätigt |
| E02 | Gerät verbunden, aber Git-Name/E-Mail für dieses Repository fehlen; konkrete lokale Abhilfe | „Lokale Anleitung öffnen“ → repositorybezogene Angaben/Befehle | „Erneut prüfen“ → E03 oder E02; globale Git-Einstellungen bleiben unberührt |
| E03 | Gerät, Projekt-/Git-Zuordnung und Autorenidentität geprüft; Test-/Vorschauwege eingerichtet | „Zur Aufgabe und loslegen“ → Aufgabenbeginn | „Eigene Codex-Verbindung ansehen“; Codex noch nicht verbunden, kein Veröffentlichungsrecht |
| A01 | Bereits gespeicherte eigene Bearbeitung: Entwurf vorhanden, Tests und Vorschau noch offen | „Tests & Vorschau vorbereiten“ → Vorbereitung der Prüfungen innerhalb der Aufgabe | „Dateien öffnen“ → eigene Arbeitskopie, „Auftrag mit Codex vorbereiten“ → A03 |
| A02 | Gerät offline: letzte gemeldete Speicherung, mögliche spätere lokale Änderungen und Rückfrage | „Verbindung erneut prüfen“ → A01 oder A02 | „Anforderungen weiterplanen“ → P02; keine Ausführung auf fremdem Gerät |
| A03 | KI-Auftrag prüfen: Ziel, Dateiumfang, eigenes Gerät, persönliche Verbindung und Grenzen | „Diesen Auftrag starten“ → Ausführungszustand bei der Aufgabe | „Auftrag ändern“ in A03, „Selbst bearbeiten“ → A01; kein Start durch Öffnen |
| Z01 | Einladen: Projekt, Mitwirkungsrolle und geplanter persönlicher Link; tatsächlicher Weg noch zu prüfen | „Einladungslink vorbereiten“ → noch auszuarbeitender Linkzustand | „Zurück zum Projekt“ → P01; keine behauptete E-Mail-Zustellung |
| Z02 | Einladung lesen: Absender, Projektziel, Rolle Mitarbeiten und erster Prüfbeitrag | „Mit eigenem Konto beitreten“ → P01 oder R01 bei Prüfauftrag | „Einladung ablehnen“ → persönlicher Start; eigene Anmeldung, keine Gerätefreigabe |
| R01 | Ergebnis prüfen als Markus: Aufgabe, Version, Vorschau, Tests, Prüffrage und Autor | „Ergebnis annehmen“ → R04 | „Änderungen anfordern“ mit Kommentar → R02 für Marco; Entscheidung an Version binden |
| R02 | Änderungen angefordert als Marco: Feedback zu E-02 und Fortsetzung derselben Aufgabe | „Eigene Arbeit fortsetzen“ → eigene Arbeitskopie | Rückmeldung bleibt am Ergebnis; keine neue Aufgabe erforderlich |
| R03 | Ergebnis veraltet: E-02 historisch und E-03 aktuell ungeprüft | „Aktuellen Stand E-03 prüfen“ → Prüfansicht mit E-03 | „Änderungsbeschreibung lesen“; alte Annahme nicht übertragen |
| R04 | E-03 von Markus angenommen; Integration offen, Livegang nicht beauftragt | „Übergabe ansehen“ → L01 | „Zur Projektübersicht“ → P01; Annahme ist kein Merge oder Deployment |
| W01 | Bestätigter Projektbrief Version 2 bereits offen, dazu ein unbestätigter Vorschlag | „Übergabe mit diesen Grundlagen vorbereiten“ → noch auszuarbeitendes Übergabepaket | „Eintrag vorschlagen“; Übernahme erst nach Bestätigung |
| F01 | Beide Fassungen bereits gegenübergestellt, zusammengeführter Textvorschlag sichtbar | „Gemeinsamen Text speichern“ → bewusster Speicherversuch mit aktuellem Stand | „Entwurf behalten & später entscheiden“; keine automatische Zusammenführung |
| L01 | Teamannahme vorhanden; GitHub-, Zielbranch- und Live-Nachweise noch offen | „Übergabeanforderungen ansehen“ → Anforderungen innerhalb Releasevorgang | „Zurück zum Ergebnis“ → R04; kein automatischer Push, Merge oder Livegang |
| P02 | Plan & Aufgaben: erste Etappe mit drei Aufgaben und späteren Ideen; Liste sichtbar | „Aufgabe hinzufügen“ → benannter Eingabezustand | „Fortsetzen“ bei laufender Aufgabe → A01; Board ist nur alternative Darstellung |
| P03 | Austausch: Termintypen-Frage, Antworten und verlinkte bestätigte Entscheidung | „Antwort hinzufügen“ im Projektgespräch | „Entscheidung ansehen“ → W01; Nachricht startet keinen Entwicklungsauftrag |
| P04 | Ergebnis E-03 bereits angenommen, E-02 historisch; Übernahme und Livegang offen | „Ergebnis & Übergabe öffnen“ → R04 beziehungsweise L01 | „Verlauf“ → frühere Version; keine zweite Kopie des Ergebnisobjekts |

Die IDs benennen feste Entwurfszustände, keine fertigen Routen. Die Produktaktionen und Felder der visuellen Ansichten sind statisch; nur die Entwurfsnavigation wechselt Ansichten. Editor, laufende Ausführung und kleinere Eingabezustände sind nicht vollständig dargestellt. Übergänge beschreiben den geplanten Produktweg und führen im Entwurf nicht tatsächlich Speicherungen oder Prüfungen aus.

Die Folge enthält bewusste Zeitsprünge: N03 zeigt die frisch angelegte Planungsaufgabe; A01 zeigt dieselbe Aufgabe erst nach späterer Einrichtung und bereits gespeicherter Bearbeitung. E03 bestätigt vorbereitete Fähigkeiten, aber führt weder selbst Änderungen noch Tests aus. R01 zeigt E-02, R03 den späteren neuen Stand E-03 und R04 dessen noch spätere Annahme. Diese Zustände sind keine Aufzeichnung eines durchgelaufenen Assistenten.

### Ergänzte Übergangsansichten

Die visuelle Durchsicht hat vier zusätzliche Kernzustände erforderlich gemacht. Damit enthält die Fassung insgesamt **30 statische Bildschirmansichten**.

| ID | Sichtbarer Zustand | Hauptaktion → Ziel | Speicherwirkung und Abbruch |
| --- | --- | --- | --- |
| A00 | Erstmaliger Aufgabenbeginn ohne Codearbeit, konkreter Ablaufentwurf | „Ablauf als Arbeitsgrundlage speichern“ → gespeicherter Plan derselben Aufgabe | Umsetzung über E01; Markus optional über Z01; noch kein technischer Erfolg |
| A04 | Abgeschlossene technische Prüfungen und Vorschau für Beispielstand E-02 | „An Markus zur Prüfung vorbereiten“ → A05 | Vorschau ansehen oder weiter bearbeiten; neuer Code erfordert neue Belege |
| A05 | Ergebnisstand E-02, Markus als Prüfer und konkrete Prüffrage | „Stand E-02 an Markus übergeben“ → angefragte Prüfung R01 | Zurück zu eigenen Prüfungen; Übergabe erst nach bestätigter Speicherung |
| R00 | Markus formuliert einen Änderungswunsch zu E-02 | „Änderungswunsch an Marco zurückgeben“ → R02 | Pflichtfeld Rückmeldung; Zurück zum Ergebnis erhält Entwurf |

Der in der Tabelle genannte Aufgabenbeginn ist nun als A00 dargestellt. A01 zeigt weiterhin spätere gespeicherte Bearbeitung. Für die Übergabe ist A05 maßgeblich, für die begründete Rückgabe R00.

Die vollständigen visuellen Kernketten sind: **S02 → N01 → N02 → N03 → A00 → E01/E02/E03 → A01**; **B01 → B02 → bestehende Aufgabe → A01**; **A01 → A04 → A05 → R01 → R00 → R02 → Überarbeitung → R03 → aktuelle Prüfung → R04 → L01**. A03 ist eine optionale Abzweigung vor der Bearbeitung. Nicht alle lokalen Editor- und Ausführungszustände sind bereits gezeichnet.

## 3 Ablauf A Ein neues Projekt beginnen

Ausgangslage: Marco möchte eine Buchungswebsite bauen; keine technische Verbindung wird vorausgesetzt.

1. **S02 → N01:** „Neue Idee starten“. Name und Ziel ausfüllen: „Kunden sollen einen freien Termin buchen können.“
2. **N01 → N02:** „Weiter: erste Version“. Der private Projektentwurf wird als solcher gespeichert; Pflichtfelder nennen den konkreten fehlenden Inhalt.
3. **N02:** Erste Version: „Termin auswählen und Buchung bestätigen“. Abnahmekriterium: „Markus kann eine Testbuchung durchführen und sieht, ob sie erfolgreich war.“ Weitere Ideen wandern in „Später“.
4. **N02 → N03:** „Projekt mit erster Aufgabe anlegen“ erzeugt im Sollprodukt genau ein Projekt mit Aufgabe „Buchungsformular fertigstellen“. Während der Speicherung ist wiederholte Anlage verhindert; bei Fehler bleiben alle Eingaben erhalten.
5. **N03 → A00:** „Erste Aufgabe öffnen“ führt zum Aufgabenbeginn: Terminwahl und Bestätigung beschreiben. Dafür ist kein Gerät nötig. A01 bildet erst die spätere gespeicherte Bearbeitung ab.
6. **N03 → E01 → E02/E03:** Wenn Dateien bearbeitet werden sollen: Einrichtungsplan herunterladen, manuelle lokale Anleitung ausführen und Verbindung tatsächlich prüfen. E02 zeigt fehlenden Git-Namen beziehungsweise fehlende E-Mail für dieses Repository. E03 bestätigt Fähigkeiten und führt zur Aufgabe zurück; kopierter Befehl bedeutet noch nicht bereit.
7. **Späterer Stand A01:** Nach tatsächlicher Bearbeitung und Speicherung „Tests & Vorschau vorbereiten“. „Dateien öffnen“ ist nebengeordnet; optional **A03**. Erst „Diesen Auftrag starten“ beginnt Codex, sofern die persönliche Verbindung verfügbar ist.
8. **N03/P01 → Z01:** Markus optional einladen. Projektanlage wird dadurch nicht blockiert. **Z02 → P01** beziehungsweise direkt zur angefragten Prüfung.

Bei Abbruch in N01/N02 führt **S01** später zum beschrifteten Projektentwurf zurück. Bei Abbruch während E01 bleibt die Aufgabe nutzbar; „Einrichtung fortsetzen“ führt an den offenen Schritt.

Erster nachweisbarer Nutzen: Ziel, erste Version und nächste Aufgabe sind verständlich gespeichert. „Gemeinsam Code bearbeiten“ darf erst erscheinen, wenn ein erreichbares gemeinsames Remote und passende Rechte tatsächlich vorhanden sind; ein neues lokales Startprojekt allein genügt nicht.

## 4 Ablauf B Ein bestehendes Projekt weiterführen

Ausgangslage: Marco hat vorhandene Arbeit und möchte den Buchungsablauf verbessern.

1. **S02 → B01** oder **S01 → P01** bei bereits bekanntem Projekt. Bekannte Projekte werden nicht erneut angelegt.
2. **B01:** Eigenes Gerät und unterstützte Quelle wählen. Eine öffentliche Website-Adresse allein ist kein Quellcodeimport. Fehlender Gerätezugang führt zu **E01**, danach zurück zu B01.
3. **B01 → B02:** Identität, Repositoryzuordnung, lokale Änderungen und bekannte Prüfwege lesen. Unbekannte Fähigkeiten heißen „Noch nicht geprüft“.
4. **B02:** Beispiel: „Zwei lokale Dateien geändert. Diese Änderungen bleiben erhalten.“ Der Nutzer bestätigt die richtige Quelle; ein falsches Projekt führt zurück nach B01.
5. **B02:** Das nächste Ziel wird bereits hier erfasst: „Das Buchungsformular soll fehlende Eingaben verständlich erklären.“ „Mit dieser Aufgabe weiter“ speichert eine Aufgabe im bestehenden Projekt und führt direkt dorthin. Kein N02-Assistent, keine erneute Projektanlage.
6. **Aufgabenbeginn → später A01:** Vorhandene Kopie zuordnen und bearbeiten; A01 zeigt den späteren gespeicherten Arbeitsstand der Aufgabe „Buchungsformular fertigstellen“. Erst danach werden Tests und Vorschau vorbereitet. Der Entwurf zeigt diese dazwischenliegenden Arbeitsschritte nicht vollständig.
7. **A01 → A02:** Bei Offlinezustand bleibt die letzte bestätigte Speicherung sichtbar. „Erneut prüfen“ kehrt erst nach tatsächlicher Verbindung zu A01 zurück.
8. **S01 → A01:** Nach Pause zur richtigen Aufgabe und Arbeitskopie zurückkehren. Nach Gerätewechsel erklären, wo ein lokaler Entwurf liegt.

Ein GitHub-Abgleich zeigt Quelle und Zeitpunkt. Ein Verbindungsfehler wird nicht als leerer Projektstand interpretiert. Veröffentlichter Code, Studio-Aufgabe und persönliche uncommittete Änderungen bleiben unterscheidbar.

Erster nachweisbarer Nutzen: Marco erkennt seinen Bestand, erhält vorhandene Änderungen und beginnt einen begrenzten nächsten Auftrag.

## 5 Ablauf C Ein Ergebnis gemeinsam prüfen

Ausgangslage: Marco hat eine Aufgabe bearbeitet. Markus soll den Buchungsablauf beurteilen.

1. **A01 → A04:** Marcos Änderungen sind bereits gespeichert. „Tests & Vorschau vorbereiten“ führt im Sollablauf zu tatsächlichen Prüfungen; A04 zeigt deren erfolgreich abgeschlossenen Beispielzustand. Die laufende Ausführung ist noch nicht gezeichnet. Eine fehlgeschlagene Prüfung muss sichtbar bleiben.
2. **Geplante Prüfübergabe → R01:** Sie verlangt einen konkreten Ergebnisstand, benannten Prüfer und Prüffrage. R01 zeigt den später bereitgestellten Stand E-02. Die dargestellte P04-Ansicht liegt zeitlich noch später und zeigt bereits E-03 nach dessen Annahme.
3. **Markus öffnet R01:** Angezeigt werden Autor Marco, E-02, Beispiel-Testbelege, statische Vorschau und Prüfumfang. „Vorschau in groß öffnen“ bezeichnet einen geplanten späteren Produktweg, keine hier funktionierende Vorschau. Eigener Geräteaufbau ist für Feedback nicht nötig.
4. **R01 → R00 → R02:** Markus wählt „Änderungen anfordern“ und formuliert in R00 den konkreten Wunsch zur Namensfehlermeldung. Erst „Änderungswunsch an Marco zurückgeben“ speichert die Rückmeldung; Marco ist wieder dran.
5. **R02 → eigene Arbeit:** „Eigene Arbeit fortsetzen“ führt zur Überarbeitung. A01 zeigt nur das Muster einer gespeicherten Arbeit, nicht bereits die spätere Korrektur. Der bisherige Prüfstand bleibt historisch, die neue Version bekommt E-03.
6. **Später R03:** Markus sieht, dass E-03 neu und E-02 historisch ist. „Aktuellen Stand E-03 prüfen“ führt im Sollprodukt zu einer Prüfansicht wie R01, jedoch mit E-03; die feste R01-Abbildung selbst zeigt weiterhin E-02.
7. **Neue Prüfung von E-03 → R04:** Markus nimmt genau E-03 an. P04 zeigt anschließend dieselbe Annahme in der Ergebnisliste. Es wird kein Ergebnis automatisch zusammengeführt oder online gestellt.
8. **R04 → L01:** Der nächste Integrationsschritt zeigt vorhandenen PR beziehungsweise die noch offene GitHub-Übergabe. Ein neuer Zielbranchstand verlangt erneute kombinierte Prüfung.

Ein Autor kann die eigene Codearbeit im gemeinsamen Ablauf nicht selbst annehmen. Ein doppelter Klick erzeugt keine zweite Entscheidung. Wird der Ergebnisstand während der Entscheidung verändert, muss neu geladen und der richtige Stand erneut beurteilt werden.

Erster nachweisbarer Nutzen: Beide verstehen Feedback und Zuständigkeit; eine Annahme ist eindeutig an einen Ergebnisstand gebunden.

## 6 Konkrete Text- und Inhaltsentwürfe

### S01 Start bei Rückkehr

Überschrift: „Hallo Marco.“ Darunter die führende Karte „Hier weitermachen · Buchungswebsite“ mit Titel „Das Buchungsformular steht.“

Text: „Zuletzt hast du deinen Entwurf gespeichert. Als Nächstes: den Ablauf ausprobieren und zur Prüfung vorbereiten.“ Hauptaktion: „Meine Arbeit fortsetzen“; nebengeordnet „Aufgabe ansehen“.

Darunter „Du bist gefragt“ mit höchstens drei Rückfragen/Prüfungen, anschließend Projekte und wenige tatsächliche Änderungen. „Zuletzt geöffnet“ wird verwendet, wenn nur das Öffnen nachgewiesen ist.

### P01 Projektüberblick

Titel: „Buchungswebsite“. Ziel: „Kunden sollen freie Termine selbst buchen können.“ Erste Etappe: „Termin auswählen und eine sichtbare Bestätigung erhalten.“ Zuständig: Marco; Mitglieder: Marco und Markus.

Die feste P01-Abbildung zeigt Marco: „Buchungsformular fertigstellen. Der Entwurf ist gespeichert. Prüfe jetzt, ob Terminwahl und Bestätigung verständlich funktionieren.“ Aktion: „Meine Arbeit fortsetzen“. Eine eigene Markus-Variante des Projektüberblicks ist noch auszuarbeiten; R01 zeigt seinen konkreten Prüfweg.

### E02 Einrichtung fehlgeschlagen

Titel: „Ein Schritt fehlt noch.“ Das Gerät ist verbunden, aber das Repository kennt Marcos Git-Namen und E-Mail noch nicht. „Lokale Anleitung öffnen“ erklärt repositorybezogene Angaben/Befehle; „Erneut prüfen“ prüft dasselbe Projekt. Globale Git-Einstellungen werden dafür nicht geändert. Projekt, Profil und bisherige Einrichtung sind gespeichert.

Die endgültige Fehlermeldung wird aus dem tatsächlichen Fehler abgeleitet. Ein unbekannter Fehler darf diese konkrete Ursache nicht vortäuschen.

### R01 und R04 Prüfung

R01: „Markus, deine Rückmeldung ist gefragt“ und „Funktioniert die Testbuchung?“ Darunter Stand E-02, Autor Marco, statische Beispielvorschau sowie die Prüfpunkte Terminwahl, fehlende Eingaben und Bestätigung. „3 Tests bestanden“ ist ausdrücklich Beispielnachweis, kein in diesem Auftrag ausgeführter Test.

R04: „Der Entwurf ist angenommen.“ Markus hat E-03 angenommen; Übernahme in den gemeinsamen Zielstand ist offen, Livegang nicht beauftragt. Die kurze Erfolgsmeldung verdeckt die offenen Folgeschritte nicht.

### W01 Projektwissen

Der Projektbrief Version 2 ist bereits offen und bestätigt: Ziel der ersten Version, ein einfacher Buchungsablauf, verständliche Pflichtfeldhinweise, noch keine Zahlung oder Erinnerungsnachricht. Quelle ist die bestätigte Entscheidung; Gültigkeit ist die erste Etappe, keine Aussage zum Live-Stand. Darunter liegt der noch unbestätigte Erinnerungsvorschlag von Markus.

„Aus dem Gespräch vorgeschlagen“ ist ein Entwurf. „Von Marco bestätigt“ ist eine bewusste Übernahme. Eine technische Momentaufnahme nennt zusätzlich den datierten Beleg.

Die sichtbare Aktion lautet „Übergabe mit diesen Grundlagen vorbereiten“. Der Übergabepaket-Zustand ist noch nicht dargestellt. F01 zeigt beide Textfassungen und einen bereits zusammengeführten Vorschlag; erst „Gemeinsamen Text speichern“ soll diesen nach bewusster Prüfung zur gemeinsamen Fassung machen.

## 7 Fehler, Unterbrechungen und erhaltene Daten

| Zustand | Sichtbare Aussage | Erhalt und Fortsetzung |
| --- | --- | --- |
| Leerer Bereich | „Hier ist noch keine Aufgabe. Lege euren ersten Schritt fest.“ | Direkte Anlage; keine irreführenden Nullstatistiken |
| Pflichtfeld fehlt | „Beschreibe kurz, was als Erstes funktionieren soll.“ | Feldbezogene Meldung; andere Eingaben bleiben erhalten |
| Speichern läuft | „Wird gespeichert …“ | Kein zweiter Anlageversuch, keine voreilige Erfolgsmeldung |
| Speicherung gescheitert | „Deine letzte Eingabe wurde noch nicht gespeichert.“ | Eingabe erhalten, erneut versuchen oder eigene Kopie sichern |
| F01 gleichzeitige Änderung | „Markus hat diese Beschreibung inzwischen geändert.“ | Beide Fassungen vergleichen; keine stille Überschreibung |
| A02 Gerät offline | „Dein Arbeitsgerät ist nicht erreichbar. Neue Ausführung ist gerade nicht möglich.“ | Planung und Fragen erreichbar; keine fremde Ausführung |
| Verbindung im Lauf verloren | „Der aktuelle Ausführungsstand ist noch nicht bestätigt.“ | Erst abgleichen; keinen automatischen doppelten Job starten |
| Persönliches Abo-Limit | „Der Auftrag ist unterbrochen. Dein Zwischenstand ist erhalten.“ nur bei belegter Sicherung | Später fortsetzen oder manuell weiterarbeiten; keine API-Ausweichroute |
| Vorschau nicht erreichbar | „Diese Vorschau ist gerade nicht erreichbar.“ | Ergebnisbeschreibung, Stand und Belege bleiben sichtbar |
| Veraltete Prüfung | „Diese Rückmeldung gilt für einen früheren Stand.“ | Historie erhalten; aktuelle Version ausdrücklich neu prüfen |
| Einladung abgelaufen | „Diese Einladung ist nicht mehr gültig.“ | Projektverantwortlichen nennen, neuen Zugang anfordern |
| GitHub nicht erreichbar | „Letzter bestätigter Abgleich: …“ | Datierter letzter Stand; keine Behauptung aktueller Synchronität |

Abbrechen verlässt den Schritt bewusst; bestehende gespeicherte Arbeit wird nicht gelöscht. Bei tatsächlich ungespeicherten Eingaben muss eine klare Wahl zwischen Weiterbearbeiten und gesichertem Verlassen möglich sein. Ein gespeicherter Projektentwurf bleibt von einem technisch bereiten Projekt unterscheidbar.

### Gemeinsame Regeln für Feldinhalte

- N01 fragt nach Name, Zielgruppe und Nutzen; keine technische Projektkonfiguration in diesem Schritt.
- N02 fragt nach erstem Ergebnis und dessen Erkennbarkeit; spätere Ideen bleiben sichtbar nachgeordnet.
- B02 trennt gelesene Quellenbefunde vom direkt erfassten nächsten Ziel und legt nur eine Aufgabe im vorhandenen Projekt an.
- E01 zeigt den manuellen Einrichtungsweg mit herunterladbarem Plan; Prüfung folgt nach lokaler Ausführung.
- A01 zeigt eine verantwortliche Person, eine eindeutige Aufgabe und bereits gespeicherte Arbeit; Tests und Vorschau sind noch offen.
- A03 zeigt eine Zusammenfassung des tatsächlichen Auftrags vor dessen Start.
- Z01 benennt Projekt, Empfänger und Rolle vor Erstellung der Einladung.
- R01 verlangt einen aktuellen Ergebnisstand; bei Rückgabe ist verständliches Feedback erforderlich.
- W01 trennt Entwurf, bestätigtes Wissen und überholte Aussagen.
- L01 verlangt Quelle und Zeitpunkt für jede Aussage über GitHub oder eine Zielumgebung.

Diese Regeln sind bei der visuellen Durchsicht gegen die jeweilige Ansicht zu halten. Für Platzhalter gibt es keine echten Zugangsdaten, privaten Pfade oder Produktionsinhalte.

## 8 Visuelle Prioritäten und Mobilverhalten

Die SCHMAQQ-Farbwelt bleibt erhalten: heller Papiergrund, dunkle Schrift, Grün für die nächste Handlung, Koralle für nötige Aufmerksamkeit. Status besitzt immer zusätzlichen Text. Alle dargestellten Beispieldaten werden als Entwurf gekennzeichnet.

Pro Seite: Titel und Kontext, führende Handlung, aktueller Arbeitsstand, ergänzende Informationen. Keine dekorative Statistikreihe vor der eigentlichen Arbeit. Fließtext soll gut lesbar sein; Datum und technische Herkunft dürfen kleiner, aber nicht winzig erscheinen.

Mobil bleiben Lesen, Antworten, Zuweisen und Prüfen vollständig erreichbar. Lange Texte umbrechen. Das optionale Board darf in seinem eigenen Bereich scrollen; die gesamte Seite nicht. Touchziele, sichtbarer Tastaturfokus, vergrößerbarer Text und verständliche Screenreader-Namen sind spätere technische Abnahmepunkte.

## 9 Durchsicht mit echten Nutzern

Die statischen Ansichten prüfen zunächst Begriffe, Inhalt und Reihenfolge. Ein erfolgreicher statischer Durchgang ist kein Nachweis funktionierender Speicherung, Verbindungen oder Ausführung.

| Aufgabe ohne Klickanleitung | Erkennbares Erfolgskriterium |
| --- | --- |
| „Beginne eine einfache Buchungswebsite.“ | Ziel, erste Version und erste Aufgabe werden ohne mündliche Erklärung gefunden |
| „Führe dieses vorhandene Projekt weiter.“ | Richtige Quelle und nächste Aufgabe erkannt; lokale Änderungen nicht als verloren verstanden |
| „Mach nach der Pause weiter.“ | Richtige Aufgabe und letzter Stand innerhalb des vorgeschlagenen 30-Sekunden-Ziels gefunden |
| „Bitte gib Marco Feedback.“ | Richtige Version und Prüffrage verstanden; keine unnötige Geräteinstallation erwartet |
| „Dein Gerät ist ausgeschaltet.“ | Ausführungsgrenze erkannt; Planung und Feedback weiterhin gefunden |
| „Seit deiner Prüfung gab es Änderungen.“ | Alte Annahme nicht auf den neuen Stand übertragen |
| „Ihr habt gleichzeitig denselben Text geändert.“ | Beide Fassungen erkannt; bewusste Zusammenführung erwartet |
| „Ist diese Änderung schon online?“ | Gespeichert, auf GitHub verfügbar, angenommen, zusammengeführt und live bereitgestellt unterschieden |

Beobachtet werden Erfolg, Hilfebedarf, Suchwege, Fehlannahmen und Abbruch. Für die Behauptung „anfängertauglich“ ergänzt eine unbeteiligte Person ohne Studio-Vorwissen die Durchsicht mit Marco und Markus. Diese Tests wurden für den vorliegenden Entwurf nicht ausgeführt.

Vor einem Klickprototyp muss jede führende Aktion ein verständliches Ziel haben. Vor Produktumsetzung müssen reale Rollen, Einladungsweg, Speicher- und Geräteverfahren sowie GitHub-Feldverantwortung gegen den verbindlichen technischen Stand geprüft werden.

## 10 Quellen, Arbeitsstand und Übergabe

Maßgebliche Konzeptquelle: [Gesamtproduktkonzept V2](2026-10-24_SCHMAQQ_Gesamtproduktkonzept_V2.md), insbesondere Kapitel 5–14, Beispielszenario 15 und Abnahme 18. Lokale Zeilen beim Erstellen: Navigation 111, Einstiege 145, Wissen 173, Agenten 199, Geräte 223, GitHub 245, Betrieb 278 und Abnahme 383. Konkrete Bildschirmquelle der Korrekturrunde: `C:/Users/hi/.codex/visualizations/2026/10/24/01a16f07-7977-7a03-a98e-33fee8e5c694/studio-seitenentwurf.html`, `screens`-Einträge S01–P04. Die dortigen technischen Quellen bleiben Originalquellen; dieser Entwurf führt keinen neuen Iststand ein.

Ausgeführte Abnahme dieser Datei: neu angelegt, zurückgelesen und Bildschirm-IDs sowie drei Ablaufketten auf Vollständigkeit geprüft. In einer gebündelten Korrekturrunde wurden Bildschirmtexte, Hauptaktionen und Zeitsprünge lesend mit den festen visuellen Zuständen abgeglichen. Kein Browser-, Anwendungs- oder Nutzertest. Nur diese Datei geändert. Die visuelle Entwurfsdatei wurde nicht verändert.

Offen: Durchsicht der konkreten Bildschirmfolge, technische Zuordnung der offenen Fähigkeiten und echte Verständlichkeitsprüfung. Nächster Adressat ist der Koordinator, der Text und visuelle Ansichten gemeinsam übergibt. Der nächste Produktarbeitsschritt nach Durchsicht wäre ein begrenzter Klickprototyp, kein automatisches Deployment.

### Prüfung der visuellen Entwürfe durch den Koordinator

Nach der Textprüfung wurden vier zusätzliche Übergangsansichten ergänzt. Die finale Entwurfsansicht enthält 30 Bildschirme und wählbare Folgen für Arbeitsplatz, neuen Start, vorhandenes Projekt, gemeinsame Prüfung und Sonderfälle. Nur diese Entwurfsnavigation ist bedienbar. Produktaktionen und Felder sind bewusst statische Darstellungen; kein produktiver Klickprototyp wurde umgesetzt.

Ausgeführt am 24.10.2026: Browser-Rendering in lokalem Headless Edge über die vorhandene Playwright-Bibliothek, alle 30 Bildschirme bei 1024, 736, 390 und 320 Pixeln Breite, zusammen 120 Prüfungen. Finale Ergebnisse: keine JavaScript-Seitenfehler, kein horizontaler Seitenüberlauf und keine überstehenden Elemente in der automatischen Geometrieprüfung. Auswahl einer Ablaufgruppe und Wechsel zur nächsten Ansicht bestätigt. Desktop-Start, Desktop-Prüfansicht und mobiler Speicherkonflikt wurden zusätzlich als gerenderte Bilder visuell betrachtet. Das bestätigt Darstellung und Entwurfsnavigation, keine funktionierende Speicherung, Ausführung oder Nutzerverständlichkeit.

Prüfwerkzeug: [studio-entwurf-pruefen.mjs](studio-entwurf-pruefen.mjs). Ergebnisprotokoll: [Studio Entwurf Prüfung](2026-10-24_Studio_Entwurf_Pruefung.json). Vor dem finalen Lauf wurden ein Windows-Importpfad und die bestehende Renderer-Ausgabedatei im Prüfaufbau korrigiert; für vollständige mobile Screenshots wurde der lokale Prüfrahmen vergrößert. Die Produktoberfläche und ihre Konfiguration wurden nicht verändert.

Vorschlag für die Arbeitsbasis, 24.10.2026: Auf Basis des Gesamtproduktkonzepts V2 liegen nun 30 benannte Bildschirmzustände und drei Kernabläufe für den Zwei-Personen-Studio-Alltag vor. Stand ist dieser lokale Entwurf, kein Implementierungscommit. Selbst ausgeführt wurden Textlektüre, Dokumentprüfung sowie die oben begrenzte Renderingprüfung; tatsächliche Produkt- und Nutzertests bleiben UNVERIFIED. Offene Punkte und nächster Schritt stehen oben. Mangels Schreibrecht im externen Vault bleibt dieser Vorschlag hier statt in `vault/05_Eingang/`.
