# SCHMAQQ Studio Vorbereitung für Hermes

Dieses Paket dient dem ersten echten mobilen Studio-Test für Marco. Einstieg ist **HERMES_AUFTRAG.md**. Marcos kurze Anleitung steht in **MOBILTEST.md**.

Enthalten sind eine tatsächliche gebaute Anwendung, ein verifiziertes Git-Quellbundle, Artefakthashes und sanitisiert dokumentierte Prüfungen. Die beigelegten Konzept-/Seitenentwürfe sind Gestaltungsvorgaben und keine Implementierung im Runtimearchiv.

## Kandidat

- Source: `41d9f30245fa056b52042181eb7ddadedbc7ff8d`
- Branch: `local/studio-navigation-20261024`
- Runtime: `studio-runtime.tar.gz`, SHA256 `065556221d3ffbcb6cfda4c76f20b31f454aa45b8c2730c161fc322b02d571a3`
- Bundle und genaue Prüfergebnisse: `candidate.json` und `SHA256SUMS`.

Die Quelle ist sauber lokal committed, aber der neue Commit war auf GitHub beim Abruf nicht verfügbar. Das beigefügte Quellbundle ermöglicht Hermes den exakten Checkout ohne Auswahl eines veralteten Branches. Es enthält versionierte Codehistorie, keine ignorierten privaten Studio-Daten.

## Stand

Lokaler Gesamtcheck: 151 PASS, 0 FAIL, 21 ausdrücklich ausgelassene Linuxfälle; Build/TypeScript/Source Guard PASS. Artefaktprüfung und synthetischer Runtime-Smoke PASS. Synthetischer mobiler Konto-/Aufgaben-/Wiederanmeldelauf bei 390/360 PASS. Öffentliche Loginseite nur unangemeldet geprüft.

Offen: Linux-Release-/Recoveryprüfung, aktuelle Live-Datenkompatibilität, echter Marco-Zugang und persönliche mobile Abnahme. Kein Production-Deployment wurde durchgeführt. Keine echten Konten, Passwörter, Zugangslinks, Datenbanken oder privaten Konfigurationen sind im Übergabe-ZIP enthalten.

Die Arbeitsdateien neben dem ZIP können lokale synthetische Testdaten enthalten. **Nur das explizit erzeugte Übergabe-ZIP weitergeben**, nicht den gesamten Vorbereitungsordner. Ein neu gebautes oder geändertes Runtimearchiv benötigt einen neuen Hash und Nachweis.
