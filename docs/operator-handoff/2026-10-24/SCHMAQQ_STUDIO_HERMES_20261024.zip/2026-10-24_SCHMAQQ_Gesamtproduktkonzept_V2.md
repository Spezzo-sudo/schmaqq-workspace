# SCHMAQQ Gesamtproduktkonzept und Studio Bedienung

Stand 24.10.2026 · Version 2 · Konzept zur gemeinsamen Durchsicht

## 1 Die Produktentscheidung auf einer Seite

**SCHMAQQ Workspace soll der dauerhafte gemeinsame Arbeitsraum sein, in dem Menschen und freigegebene KI-Unterstützung aus Zielen nachvollziehbare Ergebnisse machen. Studio ist der erste Fachbereich für die Entwicklung und Pflege digitaler Produkte.**

Ein Nutzer soll ein neues Vorhaben beginnen oder ein bestehendes aufnehmen können und später ohne alten Chat verstehen: Was wollen wir erreichen? Was wurde entschieden? Wer arbeitet woran? Was wurde tatsächlich geprüft? Was ist mein nächster Schritt?

Das erste vollständige Nutzererlebnis richtet sich an Marco und Markus, mit eigenen Konten, Geräten und Arbeitskopien. Es wird verständlich genug für Anfänger gestaltet. Weitere Teams, andere Arbeitsbereiche und freiwillig bereitgestellte Rechenressourcen bleiben Teil des langfristigen Produktbilds, werden aber nicht als heute vorhandene Funktionen dargestellt.

### Fünf zusammengehörige Teile

1. **Gemeinsam organisieren:** Projekte, Ziele, Aufgaben, Gespräche, Entscheidungen und Zuständigkeiten.
2. **Wissen erhalten:** geprüfte Projektgrundlagen, Dokumente, Quellen und nachvollziehbare Übergaben.
3. **Arbeit ausführen:** Menschen und ausdrücklich beauftragte Agenten auf passenden, freigegebenen eigenen Ressourcen.
4. **Ergebnisse beurteilen:** Versionen, Tests, Vorschauen und voneinander unterscheidbare Freigaben.
5. **Produkte weiterführen:** Integration, Veröffentlichung, Wartung, Fehlerbehebung, Wiederherstellung und spätere Erweiterungen.

**Erfolg der ersten Version:** Ihr könnt ein echtes Projekt gemeinsam bearbeiten, euch gegenseitig prüfen und nach einer Pause zuverlässig fortsetzen, ohne dass ein zusätzlicher Chat euch jeden Klick erklären muss. Der Weg bis Veröffentlichung ist vollständig beschrieben; seine Ausführung bleibt gesondert zu beauftragen.

### Verbindlichkeit dieser Fassung

Bestätigt sind der Nutzerauftrag zur Konzeptarbeit, der Fokus auf Marco und Markus sowie die bestehenden Kosten-, Daten- und Betriebsgrenzen. Die konkrete Oberfläche und ergänzten Regeln in diesem Dokument sind begründete Entwurfsvorschläge. Vorhandene Repositoryregeln und Architekturentscheidungen werden damit nicht still geändert. Es gibt keine Code-, Push-, Merge-, Deployment- oder Migrationsfreigabe.

Diese Fassung ist der Einstieg für die Gesamtsicht. [Bedienkonzept V1](2026-10-24_Studio_Bedienkonzept_V1.md) bleibt eine Detailunterlage; bei konzeptionellen Abweichungen gilt hier die ergänzte Planung, insbesondere der eigene Wissensbereich und die vollständige Produktlebensdauer. Keine bestehende Datei wird überschrieben.

## 2 Gesamtbild und Abgrenzung

```mermaid
flowchart TB
    W[SCHMAQQ Workspace]
    K[Gemeinsamer Kern: Projekte, Menschen, Wissen, Aufgaben, Entscheidungen]
    S[Studio: digitale Produkte entwickeln und pflegen]
    F[Spätere Fachbereiche]
    A[Freigegebene Agentenunterstützung]
    G[Eigene Geräte und zugelassene Ausführung]
    W --> K
    K --> S
    K --> F
    S --> A
    S --> G
    A --> G
    G --> E[Versionierte Ergebnisse und Prüfbelege]
    E --> K
```

Die Website und andere SCHMAQQ-Dienste bleiben eigenständige Anwendungen mit eigenen Daten und Releases. Gemeinsame Marke und später gemeinsamer Login bedeuten keine gemeinsamen Zugangsdaten, Datenbanken oder pauschalen Projektberechtigungen. NetzKontor wird in diesem Auftrag weder untersucht noch verändert.

Studio soll vorhandene Entwicklungswerkzeuge verbinden. GitHub bleibt maßgeblich für veröffentlichte Codezustände und dessen PR-/Issue-Daten. Studio hält den Arbeitszusammenhang und zeigt die passende nächste Handlung. Der Browser ist der Einstieg; persönliche Ausführung kann auf einem eigenen Rechner stattfinden. Ein ausgeschalteter Laptop macht seine Ausführung nicht verfügbar, auch wenn ein separat betriebener Studio-Server erreichbar ist.

Das langfristige Compute-Angebot ist eine eigene spätere Erweiterung. Es ist keine Voraussetzung dafür, dass Marco und Markus zusammenarbeiten können, und keine Erlaubnis zur Nutzung fremder Rechner oder Abokontingente.

## 3 Menschen und Verantwortlichkeiten

| Beteiligter | Bedarf | Verantwortung |
| --- | --- | --- |
| Marco oder Markus als Projektverantwortlicher | Ziel, Umfang und nächste Etappe festlegen | Priorität und fachliche Annahme verantworten |
| Bearbeitende Person | Eigenen Auftrag und Arbeitsstand verstehen | Änderung, Beschreibung und tatsächliche Nachweise liefern |
| Prüfende Person | Ergebnis ohne alten Chat beurteilen | Konkreten Ergebnisstand annehmen oder begründet zurückgeben |
| Eingeladene Person für Feedback | Ergebnis und Erwartung verstehen | Rückmeldung innerhalb des erlaubten Projekts geben |
| Betreiber | Studio verfügbar und wiederherstellbar halten | Betrieb, Zugänge, Backup, Updates und Störungen behandeln |
| Agent | Abgegrenzten Auftrag und erlaubten Kontext erhalten | Ergebnis und Grenzen nachvollziehbar zurückliefern |

Eine Person kann mehrere Rollen haben. Für die gemeinsame Codeprüfung bleibt der Autor von der prüfenden Person getrennt. Ein Agentenbericht ersetzt weder menschliche Verantwortung noch eine technische Prüfung. Ein Rollenname schafft keine technische Isolation.

Zusammenarbeit ist zunächst asynchron: Markus muss nicht online sein, während Marco arbeitet. Aufgaben, Fragen und Ergebnisse warten sichtbar auf die richtige Person. Zeiten werden lokal dargestellt; die Ereignisreihenfolge bleibt eindeutig. Es gibt keine erfundenen Online-Anzeigen oder automatischen Fristannahmen aus der Zeitzone.

## 4 Fachliches Grundmodell

Die folgenden Begriffe beschreiben das Produkt, noch kein neues Datenbankschema.

| Objekt | Bedeutung und Beziehung |
| --- | --- |
| Workspace | Gemeinsamer Identitäts- und Arbeitskontext; später sauber von anderen Teams getrennt |
| Projekt | Dauerhafter Zusammenhang aus Ziel, Mitgliedern, Wissen, Aufgaben und Ergebnissen |
| Etappe | Begrenztes nächstes Ergebnis mit Abnahmekriterien; weitere Ideen liegen in „Später“ |
| Aufgabe | Vereinbarter Auftrag mit verantwortlicher Person, Ziel und nächstem Schritt |
| Gespräch | Austausch am Projekt oder an einer Aufgabe; keine automatische Entscheidung |
| Entscheidung | Ausdrücklich bestätigte Vereinbarung mit Quelle, Zeitpunkt und gegebenenfalls Nachfolger |
| Wissenseintrag | Projektgrundlage oder Anleitung mit Quelle, Gültigkeit, Verantwortlichem und Zugriffsbereich |
| Ausführung | Ein konkreter Versuch, eine Aufgabe oder Teilprüfung auszuführen; mit Initiator, Gerät und Ergebnis |
| Arbeitskopie | Persönlicher Bearbeitungsstand; mehrere Kopien pro Aufgabe sind möglich |
| Ergebnis | Datei, Entwurf, Codeänderung, Analyse oder Vorschau mit festgehaltenem Stand |
| Prüfung | Menschlicher oder technischer Befund zu genau einem Ergebnisstand; Prüftyp bleibt sichtbar |
| Veröffentlichung | Nachgewiesene Bereitstellung eines bestimmten Stands in einer bestimmten Umgebung |

Eine Aufgabe kann mehrere Versuche, Ergebnisse, Arbeitskopien und PRs besitzen. Ein Projekt kann später mehrere Repositories umfassen; der erste geführte Einstieg darf auf ein unterstütztes Repository begrenzt bleiben. Oberfläche und Verweise dürfen die spätere Erweiterung nicht durch eine falsche Eins-zu-eins-Annahme verhindern.

Eine Person entscheidet über den Auftrag. Ein Agent bearbeitet ihn. Ein Runner führt technische Schritte aus. Diese drei Identitäten und ihre Rechte werden getrennt geführt.

## 5 Vollständiger Projektlebenszyklus

| Phase | Ergebnis für den Nutzer | Übergang |
| --- | --- | --- |
| Idee oder Bestand | Ziel und Ausgangslage verstanden | Erste Etappe bestätigen |
| Planung | Begrenzter Umfang, offene Fragen und erste Aufgabe | Aufgabe beginnen |
| Einrichtung | Benötigte Fähigkeiten für Person, Gerät und Projekt geprüft | Arbeit aufnehmen |
| Bearbeitung | Eigener gespeicherter Arbeitsstand | Tests und Vorschau ausführen |
| Prüfung | Beurteilbarer Stand mit passenden Belegen | Annehmen oder überarbeiten |
| Integration | Änderung im gemeinsamen Zielstand | Release prüfen und vorbereiten |
| Veröffentlichung | Konkrete Version am konkreten Ziel nachgewiesen | Nutzen und Betrieb beobachten |
| Wartung | Fehler und neue Anforderungen im selben Projekt | Nächste Aufgabe beginnen |
| Pause oder Abschluss | Stand und offene Pflichten erhalten | Fortsetzen, exportieren oder archivieren |

Es handelt sich nicht um einen Zwangsassistenten, der jedes Projekt bei jedem Besuch von vorn beginnt. Bestehende Projekte steigen nach einer Bestandsaufnahme an der passenden Stelle ein. Planung und Feedback können sofort stattfinden; technische Einrichtung ist nur für die entsprechende Ausführung nötig.

Ein Projekt mit fertiger Website bleibt für Wartung offen. „Erledigte Aufgabe“, „erreichte Etappe“ und „archiviertes Projekt“ sind unterschiedliche Zustände. Archivieren stoppt nicht automatisch einen laufenden Dienst und löscht keine Daten. Laufende Aufträge müssen vor Archivierung bewusst beendet oder übergeben werden.

## 6 Informationsarchitektur und Dashboard

### Persönlicher Arbeitsplatz

**Start · Projekte · Für mich · Zusammenarbeit.** Profil, persönliche Verbindungen und Hilfe stehen dauerhaft daneben beziehungsweise darunter. Administration erscheint nur für Berechtigte und ist serverseitig geschützt.

Start priorisiert eine passende Fortsetzen-Karte, konkrete Rückfragen und Prüfaufträge, eigene Projekte und wenige relevante Änderungen. „Für mich“ bleibt die vollständige Liste persönlicher Handlungsbedarfe. Ein gelesenes, aber noch unbeantwortetes Review verschwindet nicht aus ihr.

„Zusammenarbeit“ zeigt Mitglieder gemeinsamer Projekte und offene Einladungen. Es ist kein öffentliches soziales Netzwerk. Wer jemanden dazuholt, benennt immer das betreffende Projekt und die gewünschte Mitarbeit.

### Innerhalb eines Projekts

**Überblick · Plan & Aufgaben · Austausch · Wissen · Ergebnisse.**

Der eigene Bereich **Wissen** ergänzt V1 bewusst. Projektgrundlagen dürfen nicht ausschließlich in Gesprächen oder abgeschlossenen Aufgaben stecken. Er enthält Projektbrief, Anforderungen, bestätigte Entscheidungen, technische und fachliche Anleitungen sowie Quellen. Entscheidungen werden dort und im zugehörigen Gespräch als dieselben verlinkten Objekte gezeigt.

Mitglieder und Einrichtung stehen im Projektkopf. Einrichtungsprobleme erscheinen außerdem unmittelbar an der betroffenen Aktion. Quellcode und Ausführungsdetails sind aus Aufgabe und Ergebnis erreichbar; kein paralleles zweites Projektmenü für dieselbe Arbeit.

Die Suche findet Projekte, Aufgaben, Wissen und Ergebnisse innerhalb der eigenen Rechte. Ein Treffer zeigt Typ, Projekt und Aktualität und öffnet die richtige Stelle. Die erste Version benötigt dafür keine KI-Suche. Filter und zuletzt geöffnete Arbeitsstelle bleiben beim Zurückgehen erhalten.

### Regeln für die führende Handlung

| Zustand | Führende Handlung |
| --- | --- |
| Kein Projekt | Neue Idee starten oder vorhandenes Projekt anschließen |
| Einladungslink geöffnet | Einladung und Rolle prüfen |
| Eigene Arbeit unterbrochen | Genau diese Arbeit fortsetzen |
| Ergebnis wartet auf mich | Ergebnis prüfen |
| Auftrag benötigt fehlende Verbindung | Fehlenden Einrichtungsschritt fortsetzen |
| Gerät nicht erreichbar | Verbindung prüfen; Planung als Alternative |
| Keine offene eigene Arbeit | Nächste Projektaufgabe auswählen |

Für mehrere konkurrierende Aufgaben wird die zuletzt aktiv bearbeitete Arbeit hervorgehoben; neue Prüfaufträge bleiben direkt darunter sichtbar. Es gibt keine versteckte automatische Umpriorisierung allein durch KI.

## 7 Durchgängige Einstiege und erste Erfolge

### A Neue Idee ohne technische Vorkenntnisse

Marco nennt Ziel und Zielgruppe, begrenzt die erste Version und hält ein überprüfbares Ergebnis fest. Das Projekt und die erste Aufgabe werden gespeichert. Weitere Ideen landen unter „Später“. Optional kann Codex Vorschläge machen; sie sind erst nach Bestätigung Teil des Plans.

Erster Erfolg: „Mein Vorhaben ist verständlich festgehalten und ich weiß, womit ich beginne.“ Danach kann Marco einen Entwurf planen oder die technische Bearbeitung einrichten. Kein leeres Board als Ende des Assistenten.

Ein neues lokales Startprojekt ist zunächst nur auf dem eingerichteten Gerät verfügbar. Für gemeinsame Codearbeit muss ein gemeinsam erreichbares, berechtigtes Remote hinzukommen. Die Oberfläche zeigt bis dahin „Planung gemeinsam möglich; Code bisher nur auf deinem Gerät“. Eine lokale Git-Ablage allein wird nicht als gemeinsame GitHub-Anbindung ausgegeben.

### B Vorhandenes Projekt

Marco wählt ein vorhandenes Projekt oder verbindet ein unterstütztes Repository über sein Gerät. Die Prüfung erfasst Identität, lokalen Änderungsstand, bekannten Testweg und offene Einrichtung. Fremde oder uncommittete Arbeit wird erhalten. Danach legt er das nächste Ziel fest.

Erster Erfolg: „Ich erkenne meinen bisherigen Stand und kann gezielt daran weiterarbeiten.“ Eine URL zur öffentlichen Website importiert keinen Quellcode. Unbekannte Frameworks oder Testbefehle bleiben als ungeklärt gekennzeichnet.

### C Eingeladene Person

Markus erhält Projektziel, Rolle und gegebenenfalls den konkreten Prüfauftrag. Nach eigenem Zugang kann er ansehen und antworten. Eigene Ausführung benötigt erst dann eine persönliche Einrichtung, wenn er selbst Code bearbeiten will.

Erster Erfolg: „Ich verstehe, weshalb ich eingeladen wurde, und kann beitragen.“ Linkeinladung, E-Mail-Versand und Zustellung sind getrennte Zustände; nur tatsächlich unterstützte Wege werden angeboten.

### D Wiederaufnahme nach einer Pause

Start zeigt Projekt, Aufgabe, letzte bestätigte Aktion, offene Fragen und nächste Handlung. Die eigene Arbeitskopie wird wiedergefunden. Lokaler Entwurf, gespeicherte Datei und veröffentlichter Stand sind unterscheidbar. Ein Gerätewechsel erklärt, welche Arbeit nur auf dem ursprünglichen Gerät liegt.

Erster Erfolg: „Ich kann weiterarbeiten, ohne erst den alten Chat zu suchen.“ Ein neuer Agent erhält bei Bedarf ein bewusst ausgewähltes Übergabepaket statt der ungeprüften gesamten Historie.

## 8 Wissen und dauerhaftes Projektgedächtnis

### Drei Ebenen mit klarer Herkunft

1. **Originalquellen:** Code und technische Entscheidungen im passenden Repository, externe Dokumente am vereinbarten Ursprungsort, Laufzeitbelege bei der Ausführung.
2. **Geprüfte Projektgrundlagen:** Ziel, Anforderungen, bestätigte Entscheidungen, Anleitungen und Quellenverweise im Projektwissen.
3. **Arbeitsmaterial:** Gespräche, Agentenvorschläge, Recherche und offene Notizen, ausdrücklich noch nicht verbindlich.

Eine Zusammenfassung ersetzt keine Originalquelle. Ein neuer Agentenbericht überschreibt nicht automatisch eine bestätigte Entscheidung. Veraltete Aussagen werden als überholt markiert und mit der neueren Quelle verbunden; frühere Entscheidungsgründe bleiben nachvollziehbar.

### Mindestinhalt eines Wissenseintrags

Titel, Projekt, Inhalt, Quelle, Verfasser, Stand, Sichtbarkeit und fachliche Gültigkeit: Entwurf, bestätigt oder überholt. Zeitabhängige Aussagen wie „Server läuft auf Version X“ benötigen einen datierten Beleg. Dauerhafte Anforderungen und momentaner Betriebszustand werden getrennt gespeichert.

Übernahme aus einer Aufgabe: „Als Wissen vorschlagen“ erzeugt einen Vorschlag mit Herkunft. Der verantwortliche Mensch bestätigt Inhalt und Ziel. Keine automatische Hintergrundpflege und kein Agent, der jede Unterhaltung ungefragt in Regeln verwandelt.

### Bestehende Arbeitsbasis und Obsidian

Die lokale Arbeitsbasis bleibt ein eigener Wissensbestand mit Originalquellenverweisen. Studio soll perspektivisch ausgewählte Einträge verlinken oder kontrolliert importieren können. Für den ersten Umfang genügt ein bewusster Übergabe-/Exportweg; keine stille bidirektionale Synchronisierung zwischen Vault, Studio und GitHub.

Bei jeder späteren Synchronisierung wären Feldverantwortung, Konflikte, Zugriff und Löschverhalten vorher festzulegen. Secrets, Auth-Caches und Kunden-/Production-Daten gehören nicht in den Vault. „Local-only“ bleibt außerhalb von Cloud-Kontextpaketen. Ein lokaler Dateipfad beweist nicht, dass ein anderer Nutzer oder Cloud-Agent darauf zugreifen kann.

### Übergabepaket für Menschen und Agenten

Enthalten sind Auftrag, bestätigte Anforderungen, relevante Entscheidungen mit Quellen, genauer Arbeitsstand, ausgeführte versus nur berichtete Prüfungen, offene Punkte und nächste Handlung. Private Anmeldungen, Gerätegeheimnisse und unnötige Daten sind ausgeschlossen. Das Paket nennt seine Erstellungszeit und Gültigkeitsgrenzen.

## 9 Arbeit mit Agenten

Ein Agent ist eine ausdrücklich eingesetzte Unterstützung innerhalb eines menschlich verantworteten Auftrags. Die Oberfläche bietet zuerst eine konkrete Aktion wie „Aufgabe mit Codex bearbeiten“. Ein allgemeines Agenten-Cockpit ist für Anfänger nicht der Einstieg.

### Auftrag und Rückgabe

Vor Start sind sichtbar: Ziel, erlaubter Projekt-/Dateiumfang, relevante Quellen, gewünschtes Ergebnis, Abnahmekriterien, erlaubte Werkzeuge, ausführendes eigenes Gerät und Stopbedingungen. Für einfache Aufgaben verwendet die Oberfläche verständliche Voreinstellungen; Details bleiben einsehbar.

Die Rückgabe enthält Ergebnis, Änderungen, echte Prüfbelege, Unsicherheit und nächsten Schritt. „Agent fertig“ bedeutet nur, dass die Ausführung geendet hat. Erst die Prüfung entscheidet über die Annahme des Ergebnisses.

### Rollen und Delegation

Researcher sucht lesend, Builder erstellt innerhalb eines abgegrenzten Schreibbereichs, Auditor prüft gegen Auftrag und konkretes Ergebnis. Diese Rollen sind Arbeitsteilung, keine zusätzlichen Rechte. Ein Koordinator hält den Gesamtauftrag zusammen. Für die aktuelle Arbeitsweise gelten die vorhandenen Grenzen: höchstens zwei parallele Subagenten, drei Starts und eine Korrekturschleife je Auftrag; keine verschachtelten Starts und nur ein Schreiber pro Datei. Das sind Arbeitsregeln, keine bereits implementierte Produkt-Sandbox.

Studio soll nachvollziehbar darstellen können, welcher Teilauftrag von wem bearbeitet wurde. Eine tatsächliche Delegationssteuerung ist nur über nachweislich verfügbare native Fähigkeiten zulässig. Kein eigener dauerhafter Chat-zu-Chat-Bot und keine zweite kostenpflichtige Orchestrierungs-API werden als Voraussetzung eingeführt.

### Ausführungszustände

Vorbereitet → läuft → gegebenenfalls Rückfrage oder Unterbrechung → beendet mit Ergebnis, Fehler oder Abbruch. „Stopp angefragt“ und „gestoppt“ bleiben verschieden. Wiederholung erzeugt einen zugeordneten neuen Versuch und keinen doppelten Auftrag mit unklarer Herkunft.

An Abo- oder Zeitgrenzen wird ein Zwischenstand gesichert. Kein automatischer Wechsel auf bezahlte API-Endpunkte. Persönliche Codex-Anmeldung, Studio-Konto und Gerätefreigabe bleiben getrennt. Historisch vorhandene lokale Modellversuche sind kein Auftrag, neue Modellpfade zu aktivieren; zusätzliche Adapter bleiben Zukunftsoptionen außerhalb des aktuellen Abo-Umfangs.

Ein Agent kann kontrolliert Vorschläge machen, aber keine neue Berechtigung aus einem Dokument, fremden Chat oder Agentenbericht ableiten. Menschliche Freigaben werden nicht durch „Auditor PASS“ ersetzt.

## 10 Geräte und tatsächliche Ausführung

Ein Projekt kann gemeinsame Metadaten haben, während Code und Ausführung auf persönlichen Geräten liegen. Jedes Gerät hat einen Eigentümer, erlaubte Projekte, Fähigkeiten und einen datierten Verfügbarkeitsstatus. Sichtbar werden nur notwendige Informationen; private Pfade und Anmeldedaten bleiben persönlich.

### Einrichtung im passenden Moment

Planen und Feedback benötigen Projektzugang. Bearbeiten benötigt eine eigene Projektverbindung. Tests und Vorschau benötigen passende bekannte Befehle. Codex benötigt die persönliche Anmeldung und Erlaubnis. Veröffentlichung benötigt gesonderte Rechte am Ziel. Ein einzelner grüner „Verbunden“-Haken reicht dafür nicht.

Der Assistent erklärt je Schritt Zweck, Aktion und nachweisbares Ergebnis. Ein kopierter Befehl ist kein Erfolg. Das tatsächliche lokale Verfahren muss pro Betriebssystem geprüft sein. Unterbrechen und Fortsetzen sind vorgesehen. Ein signierter Ein-Klick-Installer ist ein möglicher späterer Komfortausbau, kein gegenwärtiges Versprechen.

### Offline und Ausfall

Bei ausgeschaltetem Gerät wird kein neuer Job als laufend dargestellt. Bei Verbindungsverlust während eines Jobs ist der Zustand zunächst unbekannt, bis ein verlässlicher Abgleich erfolgt. Kein automatischer Wechsel auf Markus' Rechner und keine erneute doppelte Ausführung. Planung, Fragen und bereits verfügbare Ergebnisse bleiben nutzbar, sofern Studio selbst erreichbar ist.

Eine zentrale Linux-Prüfung bleibt ein eigenes S4-Paket: isoliert, begrenzt und ohne Produktionspfade oder persönliche Auth-Caches. Keine GitHub-Actions-Abhängigkeit als künstliche Voraussetzung. Die konkrete Infrastruktur wird erst nach Bedarf und gesondertem Betriebsauftrag gewählt.

### Warteschlange und Widerruf

Ein wartender Auftrag zeigt Grund und benötigte Ressource: „Wartet, weil dein Gerät bereits eine Prüfung ausführt“ oder „Wartet auf deine Bestätigung“. Vor Start werden Rechte und Fähigkeiten erneut geprüft. Wartezeit ist keine Ausführungszeit. Laufzeit-, Parallelitäts-, Speicher- und Loggrenzen werden pro erlaubter Auftragsart festgelegt; konkrete Werte benötigen eine Bestandsprüfung. Für einen ersten zentralen Prüfdienst empfiehlt die Roadmap höchstens einen gleichzeitigen Testjob.

Bei Gerätewiderruf werden keine neuen Aufträge zugestellt. Laufende Arbeit erhält eine Abbruchanforderung, soweit das Gerät erreichbar ist. Bis zur bestätigten Beendigung steht nicht „gestoppt“. Ein verloren gegangenes oder dauerhaft unerreichbares Gerät benötigt einen eigenen Wiederherstellungsweg; ein automatischer Neustart derselben Arbeit auf fremder Hardware ist ausgeschlossen.

## 11 Entwicklung, GitHub und Freigaben

Der durchgängige Weg lautet:

**Aufgabe → eigene Kopie → Änderung → Tests und Vorschau → Teamprüfung → GitHub-Übergabe → Integration → Release → Wartung.**

### Welche Quelle ist maßgeblich?

| Information | Maßgebliche Quelle | Darstellung im Studio |
| --- | --- | --- |
| Veröffentlichter Code, GitHub-Issue, PR, GitHub-Review, Merge | GitHub | Verweis und datierter abgeglichener Stand |
| Noch lokale Änderung und persönlicher Entwurf | Eigene Arbeitskopie | Speicherort und Verfügbarkeit erklären |
| Studio-Aufgabe, Gespräch, lokale Zuständigkeit | Studio | Direkter aktueller Arbeitszusammenhang |
| Test oder Vorschau | Konkreter Ausführungsnachweis | Revision, Umgebung, Zeitpunkt, Ergebnis und Grenzen |
| Teamannahme | Studio-Prüfentscheidung zu einem Ergebnisstand | Autor, Prüfer und Gültigkeit |
| Bereitgestellte Version | Nachweis der Zielumgebung | Umgebung, Version und Prüfung; sonst unbekannt |

Bei einer mit GitHub verknüpften Aufgabe werden synchronisierte Issue-Felder vorher genau festgelegt. Lokale Ausführung und Studio-Diskussion bleiben getrennte Felder. Keine doppelte automatische Kommentarspiegelung und keine stille Überschreibung.

### Zustände, die nicht zusammenfallen dürfen

Lokal gespeichert, lokal committed, auf GitHub verfügbar, PR offen, Teamannahme, GitHub-Review, zusammengeführt und live bereitgestellt sind einzeln nachvollziehbar. Diese eindeutigen Bezeichnungen sollen in der Oberfläche verwendet werden; das alleinstehende Wort „veröffentlicht“ ist dort zu mehrdeutig. „Auf GitHub verfügbar“ bedeutet nicht „Website online“.

Ein Testergebnis gehört zu einem konkreten Stand, nicht nur zu einem Branchnamen. Neue Änderungen entwerten die aktuelle Gültigkeit alter Belege, löschen aber deren Historie nicht. Änderungen außerhalb des Studio-Editors müssen beim nächsten verlässlichen Abgleich berücksichtigt werden; eine dauerhafte Live-Überwachung darf nicht behauptet werden, wenn sie nicht existiert.

Vor Integration wird auch der aktuelle gemeinsame Zielstand berücksichtigt. Hat Markus inzwischen Änderungen übernommen, muss das kombinierte Ergebnis geprüft werden. Konflikte führen zu einer eigenen verständlichen Aufgabe und erhalten beide Arbeiten.

### GitHub-Verbindung in Stufen

Zuerst korrekte vorhandene Verweise und explizite Übergabe. Danach begrenzter Leseabgleich. Anschließend nur gezielt beauftragte Schreibaktionen. Vorhandene PRs werden wiedergefunden, wiederholte Ereignisse erzeugen keine Duplikate. Bei API-Limits oder Verbindungsfehlern bleibt der letzte bekannte Stand mit Zeitpunkt sichtbar.

Ein GitHub-Konto anmelden ist keine pauschale Freigabe für alle Repositories. Repositoryzugriff, Studio-Mitgliedschaft und Codex-Nutzung bleiben eigenständige Berechtigungen. Jede externe Mutation richtet sich weiterhin nach dem aktuellen konkreten Nutzerauftrag.

## 12 Release, Betrieb und Weiterentwicklung

Die erste Bedienfassung endete zu früh beim angenommenen Ergebnis. Das vollständige Produkt muss auch folgende Fragen beantworten: Was läuft tatsächlich? Wer ist dafür verantwortlich? Wie beheben wir einen Fehler? Wie kehren wir bei einem Problem zum vorherigen Stand zurück?

### Release als eigener Vorgang

Ein Release benennt Projekt, genauen Kandidaten, Zielumgebung, relevante Prüfungen, erforderliche Datenänderungen, Backup und Rückweg. Ein Mensch entscheidet über den konkreten Betriebsschritt. Ein erfolgreiches Deployment wird durch Erreichbarkeit und passende Versionsprüfung bestätigt, nicht durch den bloßen Start eines Befehls.

Studio muss hierfür zunächst einen nachvollziehbaren Vorgang und echte Belege darstellen können. Ein vollständiges automatisiertes Deploymentwerkzeug ist keine Voraussetzung der ersten Version. Fehlende Automatisierung wird als manueller, benannter Schritt gezeigt.

### Fehler nach Veröffentlichung

Ein Fehlerbericht wird einer betroffenen Version und Umgebung zugeordnet. Daraus entsteht eine Aufgabe mit Reproduktionsschritten und Auswirkung. Korrektur durchläuft erneut Änderung, Test, Prüfung und gesonderten Release. „Schon einmal freigegeben“ ist keine Freigabe einer neuen Version.

### Daten und Wiederherstellung

Studio-Daten, Git-Repositories und persönliche ungesicherte Entwürfe haben unterschiedliche Sicherungswege. Ein GitHub-Push sichert nicht automatisch Studio-Gespräche oder die lokale Datenbank. Backup gilt erst mit bekanntem Umfang und überprüftem Restore als belastbar. Offsite-Backups sind laut bisheriger Grenze vertagt; sie werden hier nicht aktiviert oder als vorhanden vorausgesetzt.

Administrationsansichten erklären Mitglieder, Rechte, Verbindungen, relevante Betriebszustände und Wiederherstellungsinformationen. Für normale Mitarbeit bleibt diese Komplexität im Hintergrund. Abgelaufene Berechtigungen und Gerätewiderruf werden wirksam geprüft, nicht nur durch versteckte Buttons.

Export und Archivierung müssen Projektziel, Aufgaben, Entscheidungen und Ergebnisverweise erhalten. Persönliche Secrets werden nicht exportiert. Eine spätere echte Löschfunktion benötigt eigene Regeln für Aufbewahrung und Wiederherstellung; Archivierung dient nicht als versteckte Löschung.

### Konto oder Gerät verloren

Kontowiederzugang folgt dem tatsächlich eingerichteten Anmeldeverfahren und einem nachweisbaren Identitätsverfahren. Ein anderer Projektteilnehmer erhält dadurch weder Passwort noch persönliche Codex-Anmeldung. Solange dieser Wiederzugangsweg nicht feststeht, darf die Oberfläche keine funktionierende Selbstbedienungs-Wiederherstellung versprechen.

Nach Geräteverlust wird das alte Gerät widerrufen und ein neues persönlich eingerichtet. Gemeinsame Daten kommen aus Studio, veröffentlichter Code aus dem passenden Repository und gesicherte lokale Arbeit aus einem tatsächlich vorhandenen Backup. Nicht gesicherte lokale Entwürfe können verloren sein; dafür wird keine Wiederherstellbarkeit behauptet. Der neue Arbeitsplatz prüft Projektstand und Berechtigungen erneut.

## 13 Rechte, Daten und Zusammenarbeit

Für den ersten Umfang werden fachlich Projektverantwortung, Mitarbeit und Feedback unterschieden. Vor Umsetzung ist die bestehende Rollenabbildung zu prüfen. Sichtbarkeit des Projekts bedeutet nicht automatisch das Recht, fremde Geräte zu benutzen, Einstellungen zu ändern oder ein Ergebnis zu veröffentlichen.

Einladungen haben Projektbezug, Rolle, Status und Widerrufsmöglichkeit. Ausgeschiedene Mitglieder verlieren zukünftigen Zugriff; bereits heruntergeladene Daten lassen sich dadurch nicht zurückholen. Frühere Entscheidungen bleiben mit ihrer Herkunft erhalten.

Vor dem Ausscheiden werden offene Aufgaben, Prüfaufträge und Projektverantwortung ausdrücklich zugeordnet. Die letzte verantwortliche Person kann ein aktives Projekt nicht kommentarlos ohne Nachfolger zurücklassen. Verantwortungsübergabe erfordert eine benannte übernehmende Person und deren Bestätigung; private Geräte- und Providerrechte gehen nicht mit über. Bei Verlust des einzigen Verwaltungszugangs greift der gesondert definierte Betreiber-/Wiederzugangsweg. Diese Regeln sind Sollanforderungen, keine Behauptung bestehender Kontofunktionen.

Private und projektweit geteilte Inhalte werden unterschieden. Quellen aus dem Internet, Dokumente und Agentenantworten sind Material und dürfen keine Berechtigungen erteilen. Vorschauen fremden Projektcodes müssen von der Studio-Anmeldung getrennt bleiben.

Unabhängige Kundenteams erfordern echte Isolation auf Daten- und API-Ebene. Die heutige kleine gemeinsame Studio-Datenwelt ist kein Nachweis für Mandantenfähigkeit. Öffentliche Selbstregistrierung und gemeinsames Website-SSO bleiben bis zu eigenständiger Prüfung Zukunftsarbeit.

## 14 Gestaltung und Hilfe

Die SCHMAQQ-Farbwelt bleibt Grundlage. Gestaltung unterstützt Priorität: große klare nächste Handlung, gut lesbare Beschreibung, erkennbare Personen und echte Ergebnisse. Kein Kontrollzentrum voller gleich wichtiger Kacheln.

Zentrale Begriffe: Projekt, Aufgabe, Arbeitsstand, Ergebnis, Prüfung, Arbeitsgerät. Technische Details sind erreichbar und präzise. Fachbegriffe dürfen nicht so vereinfacht werden, dass Unterschiede wie Speichern und Veröffentlichen verloren gehen.

Leere Zustände zeigen einen sinnvollen Einstieg. Fehler nennen Auswirkung, erhaltenen Stand und Abhilfe. Speicherung ist sichtbar. Gleichzeitige Änderung erhält den eigenen Text und erklärt den Konflikt. Hilfe öffnet sich möglichst an der betroffenen Stelle statt als allgemeines Handbuch.

Tastaturbedienung, sichtbarer Fokus, verständliche Namen, ausreichender Kontrast, vergrößerbarer Text und reduzierte Bewegung gehören zu den Abnahmekriterien. Auf Mobilgeräten sind Lesen, Antworten, Zuweisen und Prüfen Kernwege; umfangreiche Codebearbeitung muss nicht das erste mobile Versprechen sein. Die Seite selbst darf nicht horizontal überlaufen.

Lebendigkeit entsteht aus hilfreicher Rückmeldung: gespeicherte Arbeit, eingegangene Antwort, neues Ergebnis und erreichter Schritt. Keine erfundenen Aktivitäts- oder Produktivitätswerte.

## 15 Ein vollständiges Beispielszenario

1. Marco startet „Buchungswebsite“ und bestätigt als erste Etappe eine Testbuchung mit sichtbarer Bestätigung.
2. Anforderungen und offene Fragen liegen im Projektwissen. Eine Entscheidung begrenzt die erste Version auf einen Terminablauf.
3. Marco lädt Markus für das Projekt ein. Markus versteht das Ziel und ergänzt eine Rückfrage ohne lokale Installation.
4. Marco richtet sein eigenes Gerät und das unterstützte Startprojekt ein. Die Oberfläche erklärt, ob Code noch nur lokal liegt oder gemeinsam erreichbar ist.
5. Er beginnt die Aufgabe „Buchungsformular“. Ein optionaler Codex-Auftrag ist an diese Aufgabe und erlaubte Dateien gebunden.
6. Die Ausführung wird unterbrochen. Gespeicherte Ergebnisse und offene Rückfrage bleiben erhalten. Am nächsten Tag führt „Hier weitermachen“ genau dorthin.
7. Marco liefert einen konkreten Stand mit Test und Vorschau. Markus prüft das Verhalten und fordert verständlichere Fehlermeldungen an.
8. Marco ändert das Formular. Die alte Prüfung wird historisch. Markus nimmt den neuen Stand an.
9. Ein bestehender PR wird zugeordnet oder nach gesondertem Auftrag erstellt. Zwischenzeitliche Änderungen am Zielbranch werden vor Integration geprüft.
10. Ein gesondert freigegebener Release wird mit Zielversion und Rückweg vorbereitet. Erst ein überprüfter Betriebsnachweis macht „Online“ sichtbar.
11. Ein späterer Fehler wird mit betroffener Version als neue Aufgabe aufgenommen. Eine bestätigte Erkenntnis ergänzt das Projektwissen.
12. Nach einer Pause erkennt jeder den tatsächlichen Produktstand, die offenen Aufgaben und die letzte Entscheidung. Das Projekt muss nicht neu angelegt werden.

Dieses Szenario ist ein Sollablauf. Es behauptet keine heute durchgängig verfügbare Automatisierung.

## 16 Ausbau ohne Verlust der Gesamtvision

Die vorhandene S1–S5-Reihenfolge bleibt der technische Ausgangspunkt. Die folgenden Horizonte ordnen Produktziele ein und eröffnen keine konkurrierenden Implementierungsaufträge.

| Horizont | Produktnutzen | Abnahme beziehungsweise Voraussetzung |
| --- | --- | --- |
| Erste persönliche Nutzung | Marco beginnt oder übernimmt ein Projekt und kann eine echte Aufgabe fortsetzen | Persönlicher Arbeitsdurchlauf, Einrichtung, Speicherung, Tests, Vorschau und Wiederaufnahme |
| Gemeinsamer Studio-Alltag | Marco und Markus bearbeiten, besprechen und prüfen parallel | Eigene Identitäten/Kopien, Wissen, Übergabe, Konfliktfall, nachvollziehbarer GitHub-Übergang; S1–S5 gezielt ergänzen |
| Wiederholbarer Produktbetrieb | Ergebnisse kontrolliert integrieren, veröffentlichen und pflegen | Exakter Kandidat, isolierte Prüfung, Backup/Restore, Rückweg, gesonderte Betriebsfreigabe |
| Breiterer Workspace | Dokumente, Analysen und weitere Facharbeit mit demselben Arbeitsmodell | Nutzen auch ohne Git; versionierte Ergebnisse, Wissen und menschliche Annahme |
| Externe Teams | Andere Gruppen arbeiten unabhängig | Mandantenisolation, Rollen, Export, Wiederherstellung und Einladungslebenszyklus nachgewiesen |
| Freiwillige Ressourcen | Berechtigte Teilnehmer stellen begrenzte Ausführung bereit | Zustimmung, starke Isolation, Widerruf, Limits, Nachweise und Missbrauchsschutz |
| Geschäftsmodell | Tragfähiges Angebot für Teams oder Ressourcen | Tatsächlicher Nutzen und Kosten, geklärte Bedingungen, faire Abrechnung und Support |

Zusätzliche Anbieter, Abrechnung und Ressourcenvermittlung bleiben langfristige Optionen. Preise, Provider, Domains, SSO-Lösung und Sandboxprodukt werden nicht erfunden. Der aktuelle Auftrag bleibt innerhalb der persönlichen Abo-Nutzung und verursacht keine neuen Infrastruktur- oder Modellkäufe.

## 17 Abdeckungsmatrix zur bisherigen Vision

| Ziel aus den Quellen | Umsetzung im Konzept | Zeitpunkt | Noch zu beweisen |
| --- | --- | --- | --- |
| Dauerhafter Arbeitskontext | Kapitel 4–8 und 15 | Erste Version | Wiederaufnahme ohne alten Chat |
| Nützlich ohne KI | Kapitel 5–8 | Erste Version | Planen, entscheiden, Feedback ohne Modellverbindung |
| Neue und vorhandene Projekte | Kapitel 7 | Erste Version | Unterstützter realer Projektstart und Bestand ohne Verlust |
| Zwei Personen an getrennten Orten | Kapitel 3, 7, 13 | Gemeinsamer Alltag | Persönliche Geräte und unabhängige menschliche Prüfung |
| Wissen und Dokumente | Kapitel 8 | Grundumfang sofort, Ausbau später | Quellen, Revision, Suche, Übergabe und Rechte |
| Menschen und Agenten | Kapitel 9 | Eigener Codex-Auftrag zuerst | Auftrag, Grenzen, Zwischenstand und Nachweise |
| Agent und Gerät getrennt | Kapitel 4, 9, 10 | Von Beginn an | Keine implizite Nutzung fremder Identität oder Geräte |
| Versionen, Git, PR und Review | Kapitel 11 | S1–S3 | Korrekter Abgleich, veraltete Belege, bestehende PRs |
| Zentrale Prüfung | Kapitel 10, 11 | S4 | Isolierte tatsächliche Ausführung und Fehlerfälle |
| Betrieb und Wiederherstellung | Kapitel 12 | Vor jedem tatsächlichen Release | Restore und Rückweg für exakten Kandidaten |
| Weitere Fachbereiche | Kapitel 2, 16 | Später | Wiederverwendung des Kerns ohne Git-Zwang |
| Externe Teams und SSO | Kapitel 2, 13, 16 | Nach eigener Prüfung | Isolation und explizite Integrationsverträge |
| Freiwillige Ressourcen und Geschäftsmodell | Kapitel 16 | Langfristig | Isolation, Messung, Regeln, Wirtschaftlichkeit |

Damit sind die in den gelesenen Quellen benannten großen Produktbereiche zugeordnet. Das ist eine Abdeckungsprüfung des dokumentierten Zielbilds, keine Garantie, dass alle unausgesprochenen Wünsche oder technischen Randfälle bekannt sind.

## 18 Abnahme und offene Entscheidungen

### Konzept und UX

Die Tests aus V1 bleiben bestehen: neuer Start, vorhandenes Projekt, Einladung, Wiederaufnahme, Einrichtung, Offline-Verhalten, Prüfung, neue Version, Konflikt und Mobilnutzung. Ergänzt werden Wissen wiederfinden, Agentenübergabe, GitHub-Syncfehler, veralteter Zielbranch, fehlgeschlagener Release, Wiederherstellung und Projektarchivierung.

Außerdem werden Gerätewiderruf während wartender und laufender Arbeit, Kontowiederzugang, Geräteverlust mit ungesichertem Entwurf sowie ein Verantwortungswechsel mit offenen Aufgaben durchgespielt. Wo nur ein Verfahren beschrieben, aber noch keine Funktion vorhanden ist, wird dies als Konzeptprüfung statt als bestandener Produkttest protokolliert.

Die Testperson erhält jeweils ein Ziel und keine Klickanleitung. Erfasst werden Erfolg, Hilfebedarf, falsche Annahmen und Datenverlust. Das vorgeschlagene Wiederaufnahmeziel von 30 Sekunden ist noch kein Messwert. Für „anfängertauglich“ braucht es neben Marco und Markus eine unbeteiligte Person ohne Studio-Vorwissen.

### Technische Nachweise

Ein erfolgreicher Komponentencheck ersetzt keinen sichtbaren Browserlauf. Ein synthetischer Zwei-Rollen-Lauf ersetzt keine unabhängige menschliche Teamabnahme. Windows-/Linux-Belege ersetzen keine persönliche macOS-Prüfung. Lokale Nachweise ersetzen keine Prüfung des tatsächlich ausgerollten Stands.

Jeder Bericht nennt genaue Quelle/Revision, Umgebung, tatsächlich ausgeführte Tests, ausgelassene Fälle und verbleibende Grenzen. Ein kritischer Fehler wie Datenverlust, fremder Gerätezugriff oder irreführende Veröffentlichung verhindert die Abnahme des betroffenen Ablaufs.

### Entscheidungen vor dem jeweiligen Ausbau

| Entscheidung | Vorläufige Empfehlung | Muss geklärt sein vor |
| --- | --- | --- |
| Welche Projekte unterstützt der Einstieg? | Eine kleine geprüfte Vorlage plus klar dokumentierte vorhandene Git-Projekte | Einrichtungsentwurf und spätere Umsetzung |
| Was ist ein gemeinsames neues Projekt? | Lokalen Start erlauben, gemeinsame Codearbeit erst nach berechtigtem erreichbarem Remote | Aussage „gemeinsam bereit“ |
| Wie wird eingeladen? | Tatsächlich verfügbaren sicheren Link-/Kontoweg nutzen; E-Mail nur bei vorhandener Funktion | Einladungsgestaltung |
| Welche Rollen sind technisch möglich? | Projektverantwortung, Mitarbeit, Feedback auf bestehende Rechte abbilden | Verbindliche Rollenanzeige |
| Welche Wissensquelle führt? | Originalquellen behalten, Studio-Projektwissen mit geprüften Verweisen, Vault kontrolliert übergeben | Import oder Synchronisierung |
| Wer koordiniert Agenten? | Vorhandene aktive Codex-Sitzung und native Werkzeuge; Studio zeigt Auftrag und Herkunft | Agentensteuerung |
| Welche zentrale Prüfung? | Genau eine bestehende geeignete Lösung nach Bestandsprüfung | S4-Implementierung/Betriebsauftrag |
| Welche öffentlichen Konten, SSO, Preise oder Domains? | Offenhalten | Externe Öffnung, Integration oder Monetarisierung |

Diese Fragen blockieren die Gesamtplanung nicht. Sie begrenzen, was eine spätere Oberfläche als vorhanden versprechen darf.

## 19 Einordnung des heutigen Stands

Am 24.10.2026 wurden die relevanten Dokumente auf dem GitHub-Kandidatenbranch `local/studio-use-candidate-20261022` gelesen. Das ist ein dokumentierter Kandidat, keine Prüfung von main oder Production.

| Bereich | Aussage der gelesenen Dokumentation | Konsequenz |
| --- | --- | --- |
| Zusammenhängende Änderungsansicht S1 | Als lokal geprüft beschrieben, mit begrenzten Revisionsnachweisen | Bestehendes weiterverwenden, aktuelle Gültigkeit prüfen |
| Projektstart S2 | Begrenzter neuer/lokaler und vorhandener Projektstart; Helferbefehl nötig | Kein fertiger Ein-Klick-Einstieg; neue lokale Projekte nicht automatisch auf zwei PCs geteilt |
| GitHub-Ausbau und zentrale Prüfung | S3/S4 weiterhin eigene Arbeitspakete | Keine vollständige Live-Synchronisierung oder Dauerprüfung behaupten |
| Teamfähigkeit | Synthetischer Zwei-Host-Pilot dokumentiert | Persönliche wiederholte Alltagsabnahme bleibt eigenständig |
| Produktkandidat | Quellstand und frühere Tests dokumentiert, keine Releasefreigabe | Kein Livegang aus diesem Konzept |
| Multi-Tenant, Ressourcenmarkt, SSO | Zielarchitektur beziehungsweise spätere Phasen | Keine vorhandenen Produktfunktionen |

Das ursprüngliche lokale Checkout enthält zusätzlich zahlreiche uncommittete Änderungen. Die vorherige lokale HEAD-Abfrage ergab `9696b2d582220b6ec4ff1d70a3a5e740533c54a3`; diese Identität beschreibt nicht alle dort gelesenen Dateien. GitHub- und lokale Dokumente dürfen deshalb nicht pauschal gleichgesetzt werden.

Ein konkreter Quellenunterschied: Lokales HANDOFF beginnt mit einer nachträglichen GitHub-Sicherungsnotiz, das gelesene GitHub-HANDOFF mit „Produktkandidat für GitHub und neuen Chat“. Das Konzept verwendet für den Kandidaten die GitHub-Fassung und weist lokale Zusätze gesondert aus. Ältere Ist-Tabellen in ARCHITECTURE sind datierte Architekturtexte; jüngere STATUS-Abschnitte sind für dokumentierte Fähigkeiten relevanter, aber ebenfalls kein Live-Beweis.

## 20 Nächster Schritt und Nachweis der Konzeptarbeit

Nach inhaltlicher Durchsicht folgt ein zusammenhängender Satz statischer Seitenfolgen: Start, Projektüberblick, Projektstart, Bestandsaufnahme, Einrichtung, Aufgabe, Wissen, Einladung, Ergebnisprüfung und Releaseübersicht. Zu jeder Kernstrecke gehören leere, fehlgeschlagene und unterbrochene Zustände. Erst anschließend wird ein begrenzter Klickprototyp sinnvoll. Die Produktionsanwendung bleibt bis zum gesonderten Implementierungsauftrag unverändert.

Arbeitsauftrag dieses Durchgangs: Gesamtvision gegen Bedienkonzept prüfen und fehlende Zusammenhänge ausarbeiten. Schreibumfang: neue Konzept- und Nachweisdateien in `exports/`; keine Änderungen an Studio-Code, STATUS oder Repositoryregeln. Arbeitsbudget: eine Gesamtfassung, eine lesende delegierte Prüfung und höchstens eine gebündelte Korrekturrunde.

### Quellen

- [Produktvision auf GitHub](https://github.com/Spezzo-sudo/schmaqq-workspace/blob/local/studio-use-candidate-20261022/docs/PRODUCT_VISION.md), Datei-Blob `cd39922ca2d18d44e6c7668a43e92056aa7b0b15`: Nordstern, Zielgruppen, Arbeitsmodell, spätere Ressourcen und Geschäftsmodell.
- [Architektur auf GitHub](https://github.com/Spezzo-sudo/schmaqq-workspace/blob/local/studio-use-candidate-20261022/docs/ARCHITECTURE.md), Datei-Blob `8b5041d8696673fd53987d105d1844d54971fbea`: Verantwortlichkeiten, Identitäten, Wissen/Artefakte, Ausführung und Isolation. Volltext lokal gelesen; GitHub-Fassung abgerufen.
- [Roadmap auf GitHub](https://github.com/Spezzo-sudo/schmaqq-workspace/blob/local/studio-use-candidate-20261022/docs/ROADMAP.md), Datei-Blob `8e31a1277e416453d91fc970b406e4354b4765ba`: S1–S5, Datenverantwortung, Codezustand und spätere Horizonte.
- [Integrationsgrenzen auf GitHub](https://github.com/Spezzo-sudo/schmaqq-workspace/blob/local/studio-use-candidate-20261022/docs/INTEGRATION_BOUNDARIES.md), Datei-Blob `e70c8652843e9bca1b928c64cddbfeec39e24f88`: getrennte Website-/Studio-Verantwortung. Volltext lokal gelesen; GitHub-Fassung abgerufen.
- [Status auf GitHub](https://github.com/Spezzo-sudo/schmaqq-workspace/blob/local/studio-use-candidate-20261022/docs/STATUS.json), Datei-Blob `0e4b91e4bd9f43adbd95e57897bfdd544a8ea7f9`: gezielt S1, S2 und Nutzungskandidat ausgewertet.
- [Übergabe auf GitHub](https://github.com/Spezzo-sudo/schmaqq-workspace/blob/local/studio-use-candidate-20261022/docs/HANDOFF.md), Datei-Blob `6f7248337e038e8529d060ffe619ac84f26e10a9`: Kandidat und offene persönliche Abnahme.
- Lokale ADR-Vorschläge `schmaqq-workspace/docs/DECISIONS/0001-modular-core.md`, `0002-execution-and-providers.md`, `0003-identity-and-federation.md`: als vorgeschlagen gekennzeichnet, keine neue Annahme durch dieses Konzept.
- Arbeitsbasis-Kontextsuche vom 24.10.2026 ohne Speicherung und Modellaufruf: Grenzen, Quellenregeln, Projektkarte und Arbeitsablauf unter `C:/KI/SCHMAQQ/SCHMAQQ_Arbeitsbasis_V1/vault`.
- Nutzerentscheidungen in diesem Chat; V1-Bedienkonzept und zuvor quellenbasiert betrachteter Offline-Prototyp B2.1.

Selbst ausgeführt: gezielte lokale Lektüre, lesende GitHub-Abfragen, deterministische Kontextsuche, Konzeptausarbeitung und redaktionelle Prüfung. Keine neuen Produkt-, Browser-, Betriebs- oder Nutzertests. In den Quellen genannte bestandene Tests wurden gelesen, nicht erneut ausgeführt. Delegierte Prüfung ist eine zusätzliche inhaltliche Sicht, kein technischer oder menschlich unabhängiger Abnahmenachweis.

Abschließende lesende Gegenprüfung durch den nativen Auditor-Unterauftrag `konzept_luecken`: Alle zehn zuvor identifizierten Lücken gegenüber V1 sind in V2 auf Konzeptebene abgedeckt; kein wesentlicher verbleibender Widerspruch oder fehlender Produktbereich gegenüber dem gelesenen dokumentierten Zielbild festgestellt. Der Auditor hat keine Dateien verändert und die GitHub-Abrufe des Koordinators nicht separat wiederholt. Technische Machbarkeit, Produktreife und tatsächliche Bedienbarkeit sind damit nicht bestätigt.

### Vorschlag für die Arbeitsbasis

24.10.2026: Gesamtproduktkonzept V2 ergänzt die erste Studio-UX-Fassung um Wissen, Agenten, Geräte, GitHub, Release/Wartung und spätere Plattformphasen. Quelle ist diese Datei mit obigen GitHub-Dateiständen. Der Zwei-Personen-Fokus ist bestätigt; Detailentscheidungen bleiben Konzeptentwurf. Offen sind technische Zuordnung vor Umsetzung und echte Verständlichkeits-/Alltagsabnahme. Nächster Schritt: Konzeptdurchsicht und danach statische Seitenfolgen. Keine Code- oder Betriebsänderung. Wegen fehlender Schreibrechte im externen Vault wurde dieser Vorschlag hier erhalten und nicht in `vault/05_Eingang/` abgelegt.
