# SCHMAQQ Studio Bedienkonzept für Marco und Markus

Stand: 24.10.2026. Ausgearbeitetes Konzept zur Durchsicht, keine Implementierungs- oder Betriebsfreigabe.

## 1 Ziel und beschlossener Umfang

Marco hat den Fokus bestätigt: Zuerst einen vollständigen gemeinsamen Arbeitsweg für Marco und Markus ermöglichen und ihn so erklären, dass Menschen ohne Entwicklungswissen ihm folgen können. Die Oberfläche soll neue Projekte, bestehende Projekte und die spätere Wiederaufnahme gleichermaßen unterstützen.

SCHMAQQ Workspace bleibt die übergeordnete Plattform. Studio ist der Arbeitsbereich für digitale Produkte und Software. Die langfristige Plattformvision wird durch diesen ersten Umfang nicht ersetzt.

Das Produktversprechen lautet: **Du verstehst jederzeit, woran ihr arbeitet, wer als Nächstes dran ist und wie ihr zu einem prüfbaren Ergebnis kommt.**

Die erste Version muss diese Strecke abdecken:

**Ziel festlegen → erste Aufgabe → bearbeiten → Ergebnis ansehen → Rückmeldung → weiterarbeiten.**

Veröffentlichung ist ein eigener, ausdrücklich beauftragter Schritt. Eine angenommene Arbeit wird nicht automatisch online gestellt.

### Enthalten

- Zwei eigene Konten, gemeinsame Projekte, persönliche Zuständigkeiten.
- Neue Idee aufnehmen oder ein vorhandenes Entwicklungsprojekt anschließen.
- Projektziel, erste Version, Aufgaben und Entscheidungen zusammenhalten.
- Eigene Arbeit wiederfinden, Rückfragen beantworten, Ergebnisse gegenseitig prüfen.
- Persönliches Arbeitsgerät bei Bedarf geführt einrichten.
- Optional persönliche Codex-Nutzung über die eigene Abo-Anmeldung.
- Unterbrechung, Offline-Zustand, fehlende Einrichtung und fehlgeschlagene Prüfung verständlich behandeln.

### Später

Öffentliche Registrierung, öffentliche Personensuche, soziale Feeds, Ressourcenmarktplatz, zusätzliche Modellanbieter, API-Schlüssel, kostenpflichtige Modellzugänge, vollständig automatische Universalimporte und ein universeller Ein-Klick-Installer gehören nicht zum ersten Umfang. Eine Vollintegration von GitHub wird nicht stillschweigend als Voraussetzung für Planen oder Feedback eingebaut.

## 2 Ausgangslage und Konzeptentscheidung

Die bereitgestellte B2.1-Datei ist ein Offline-Klickprototyp. Ihr Quelltext enthält Projekte, Aufgaben, Gespräche, Entscheidungen und Beispielprüfungen. Projektanlage erzeugt lokale Metadaten; Einladungen, Entwicklung und KI sind keine echten Verbindungen. Die sichtbare Browserprüfung der Datei konnte im vorherigen Durchgang nicht abgeschlossen werden. Die Bewertung ihrer Bedienung ist daher eine begründete Hypothese aus Struktur und Interaktionscode, kein Nutzertest.

Die lokalen Studio-Unterlagen beschreiben bereits technische Projektstart-, Arbeitskopie-, Test-, Vorschau- und Review-Abläufe. Sie nennen außerdem persönliche Einrichtung und wiederholte Alltagsabnahme als offene Schritte. Bestehende Funktionen sollen in den neuen Bedienablauf eingeordnet werden; ein vollständiger Neubau ist nicht das Ziel.

Der zentrale Entwurfswechsel: Jede Ansicht hat eine Leitfrage und eine aus dem tatsächlichen Zustand abgeleitete nächste Handlung. Projektverwaltung und technische Bearbeitung dürfen nicht wie zwei unverbundene Anwendungen wirken.

## 3 Bedienregeln

1. **Ziel vor Werkzeug.** Zuerst sagen, was erreicht werden soll. Repository, Arbeitskopie und Gerät erscheinen im passenden Arbeitsschritt.
2. **Ein deutlicher nächster Schritt.** Pro Arbeitsabschnitt gibt es eine visuell führende Aktion. Alternativen bleiben erreichbar.
3. **Fortsetzen ist ein eigener Hauptfall.** Projekt, Aufgabe, Entwurf und letzte Arbeitsstelle bleiben zugeordnet und wiederauffindbar.
4. **Zustand ist überprüfbar.** „Bereit“ gilt für eine konkrete Fähigkeit, Person, ein Projekt und Gerät. Ein veralteter Bericht ist als solcher erkennbar.
5. **Einrichtung nach Bedarf.** Wer nur Rückmeldung gibt, muss kein Entwicklungsgerät verbinden.
6. **KI ist optional und ausdrücklich gestartet.** Ein Gespräch oder Vorschlag ist noch kein Auftrag.
7. **Speicherung ist sichtbar.** „Wird gespeichert“, „Gespeichert“ oder „Nicht gespeichert“ statt stiller Unsicherheit.
8. **Fachsprache hat eine zweite Ebene.** „Arbeitsgerät“ kann im Detail als Runner erklärt werden; Fehlermeldungen zeigen zuerst Auswirkung und Abhilfe.

## 4 Navigation und Orte

### Persönlicher Arbeitsplatz

| Ort | Inhalt | Hauptaktion |
| --- | --- | --- |
| Start | Wiederaufnahme, dringende Rückfragen, zuletzt verwendete Projekte | Kontextabhängig fortsetzen |
| Projekte | Alle eigenen und gemeinsam zugänglichen Projekte, Suche, Archiv | Projekt starten |
| Für mich | Zugewiesene offene Aufgaben, direkte Fragen, angefragte Prüfungen | Passenden Eintrag bearbeiten |
| Zusammenarbeit | Offene Einladungen und Personen mit gemeinsamen Projekten | Zu einem Projekt einladen |

„Zusammenarbeit“ ersetzt für diese erste Version das zuvor vorgeschlagene allgemeine „Menschen“-Verzeichnis. Es gibt keine projektunabhängige Freundschaftsanfrage oder Direktnachrichtenfunktion. Eine Frage gehört zur Aufgabe oder zum Projekt.

Profil, eigene Verbindungen und Hilfe sind dauerhaft im unteren Navigationsbereich erreichbar. Die Einrichtung wird zusätzlich dort verlinkt, wo eine fehlende Fähigkeit die Arbeit verhindert.

### Innerhalb eines Projekts

| Ort | Leitfrage | Inhalt |
| --- | --- | --- |
| Überblick | Was bauen wir und wo stehen wir? | Ziel, erstes Etappenziel, nächster Schritt, Zuständigkeit, jüngste relevante Änderung |
| Plan & Aufgaben | Was ist vereinbart und wer macht es? | Erste Version, spätere Ideen, Aufgaben als Liste oder Board |
| Austausch | Was müssen wir klären? | Projektweite Gespräche und ausdrücklich bestätigte Entscheidungen |
| Ergebnisse | Was können wir ansehen und beurteilen? | Ergebnisse mit Version, Prüfung, Rückmeldung und Veröffentlichungsstand |

Projektname und Mitglieder sind im Kopf sichtbar. „Einladen“ und „Projekteinstellungen“ befinden sich dort. Es gibt einen klaren Rückweg zur Projektliste.

Eine Aufgabe öffnet eine eigene verlinkbare Ansicht. Der Rückweg erhält Filter und Listenposition. Browser-Zurück funktioniert; Entwürfe dürfen dadurch nicht verschwinden. Auf dem Smartphone wird dieselbe Aufgabe als vollständige Seite geöffnet.

## 5 Aufbau der Startseite

### Erster Besuch ohne Projekt

Begrüßung: „Was möchtest du als Erstes machen?“

- **Neue Idee starten:** „Beschreibe dein Vorhaben. Wir halten Ziel und ersten Schritt fest.“
- **Bestehendes Projekt weiterführen:** „Nimm deine bisherige Arbeit mit und lege den nächsten Schritt fest.“
- Eine tatsächlich vorhandene Einladung wird oberhalb dieser Auswahl angezeigt: „Marco hat dich zu Buchungswebsite eingeladen.“

„Ich wurde eingeladen“ ist kein gleichwertiger toter Einstieg ohne Einladung. Falls ein Einladungslink vorliegt, führt er direkt in den passenden Ablauf.

### Rückkehr mit Projekten

Die Reihenfolge der Inhalte:

1. **Hier weitermachen:** Zuletzt aktiv bearbeitete, noch offene eigene Aufgabe; bei fehlender eigener Aufgabe das zuletzt geöffnete Projekt mit seinem nächsten Schritt.
2. **Du bist gefragt:** Angefragte Prüfungen und direkte Rückfragen, danach noch nicht begonnene zugewiesene Aufgaben. Maximal drei Einträge, dann „Alle ansehen“.
3. **Deine Projekte:** Name, kurzes Ziel, nächster Schritt und zuständige Person. Suche und vollständige Liste unter „Projekte“.
4. **Seit deinem letzten Besuch:** Höchstens wenige relevante Änderungen, direkt zum betroffenen Ergebnis oder Auftrag verlinkt.

Ein Beispiel für die Fortsetzen-Karte:

> **Buchungswebsite · Buchungsablauf vereinfachen**  
> Zuletzt hast du den Entwurf gespeichert. Die Prüfung steht noch aus.  
> Nächster Schritt: Entwurf ansehen und die Pflichtfelder prüfen.  
> **Entwurf öffnen** · Aufgabe ansehen

Die Aussage muss sich auf tatsächliche Ereignisse beziehen. Ohne belastbare letzte Aktion steht dort „Zuletzt geöffnet“, nicht „Zuletzt bearbeitet“. Ein ausgefallenes Gerät wird direkt an der betroffenen Aktion erklärt. Die Projektplanung bleibt erreichbar.

Keine allgemeinen Produktivitätswerte, Ranglisten, erfundenen Aktivitätsmeldungen oder Prozentfortschritte für unklaren Projektumfang. Ein Wert wie „2 von 4 vereinbarten Aufgaben erledigt“ ist zulässig und wird genau so beschriftet.

## 6 Neuer Projektstart

### Schritt 1 Das Vorhaben

Pflicht: kurzer Name und Antwort auf „Was möchtest du für wen erreichen?“

Beispiel: „Kunden sollen einen freien Termin bei uns buchen können.“ Vorlagen können beim Formulieren helfen, sind aber nicht notwendig. Es gibt kein obligatorisches langes Briefing.

### Schritt 2 Die erste Version

Frage: „Was muss als Erstes funktionieren?“ Der Nutzer beschreibt ein kleines Ergebnis und ein überprüfbares Erfolgskriterium. Weitere Ideen werden in „Später“ gespeichert.

Beispiel: „Besucher wählen einen Termin und erhalten eine Bestätigung.“ Erfolgskriterium: „Markus kann eine Testbuchung durchführen und erkennt anschließend, ob sie erfolgreich war.“

Ohne KI lassen sich diese Felder manuell ausfüllen. KI-Vorschläge sind ein optionaler eigener Schritt und erfordern verfügbare persönliche Codex-Nutzung. Kein automatisch angenommener Plan.

### Schritt 3 Den ersten Arbeitsschritt wählen

Auswahl: „Idee genauer planen“, „Entwurf erarbeiten“ oder „Bestehende Dateien bearbeiten / Umsetzung beginnen“. Die Formulierung bezeichnet einen Auftrag, keine Garantie automatischer Erstellung.

Das Projekt wird mit Ziel und erster Aufgabe angelegt. Es erscheint: „Dein Projekt ist angelegt. Als Nächstes: …“. Technische Einrichtung erfolgt anschließend im Kontext dieser Aufgabe, wenn sie gebraucht wird. Eine fehlende Verbindung verhindert nicht das Speichern des Projekts.

### Nach dem Start

Der Nutzer landet im Projektüberblick mit erster Aufgabe und optionalem „Markus dazuholen“. Die Einladung ist kein Pflichtschritt. Ein verlassener Assistent bleibt als deutlich beschrifteter Projektentwurf fortsetzbar; er erscheint noch nicht als fertig eingerichtetes Entwicklungsprojekt.

## 7 Bestehendes Projekt weiterführen

Der erste Umfang unterstützt vorhandene, zum Studio passende Git-Projekte. Eine Website-Adresse allein importiert keinen Quellcode. Andere Quellen bekommen eine verständliche Erklärung und können zunächst als Projektbeschreibung erfasst werden.

1. **Projekt wählen:** Bereits angeschlossenes Projekt öffnen oder „Weiteres Projekt anschließen“.
2. **Arbeitsgerät bestimmen:** Eigenes verfügbares Gerät wählen; falls nötig dessen Einrichtung fortsetzen.
3. **Quelle prüfen:** Vorhandenen Projektordner und Repository-Zuordnung prüfen. Private Pfade bleiben in der persönlichen Einrichtung.
4. **Bestand anzeigen:** Projektidentität, erkannte lokale Änderungen, bekannte Test- und Vorschauwege sowie offene Fragen. Vorhandene Änderungen werden nicht überschrieben.
5. **Nächstes Ziel festlegen:** „Was möchtest du jetzt verbessern oder ergänzen?“ Daraus entsteht eine Aufgabe.

Bei unbekanntem Projektaufbau steht ausdrücklich „Noch nicht geprüft“. Keine universelle automatische Erkennung versprechen. Nicht unterstützte Konfigurationen führen zu konkretem Hilfebedarf und erlauben weiterhin Planung.

Eine vorhandene Datei, ein früherer Testbericht und ein heute erfolgreich ausgeführter Test sind verschiedene Nachweise. Die Oberfläche zeigt Quelle, Stand und Gültigkeit beim Ergebnis.

## 8 Persönliche Einrichtung

### Fähigkeiten getrennt darstellen

| Fähigkeit | Voraussetzung | Rückmeldung |
| --- | --- | --- |
| Planen und Feedback geben | Zugang zum Projekt | „Du kannst loslegen“ |
| Projektdateien bearbeiten | Eigenes Arbeitsgerät und passende Projektverbindung | „Dateien auf deinem Gerät verfügbar“ oder konkreter fehlender Schritt |
| Tests und Vorschau ausführen | Bekannte, geprüfte Befehle und verfügbares Gerät | Letzte Prüfung mit Zeitpunkt und Ergebnis |
| Codex nutzen | Eigene Abo-Anmeldung und persönliche Erlaubnis | „Für diese Aufgabe verfügbar“ oder konkrete Abhilfe |
| Veröffentlichen | Gesonderte Zielverbindung und Berechtigung | Eigener, ausdrücklich beauftragter Ablauf |

### Geführter Einrichtungsweg

Ein Schritt pro Ansicht: Zweck, Aktion, erwartetes Ergebnis. Fortschritt nur für diese Einrichtung, beispielsweise „Schritt 2 von 4“.

1. Eigenes Gerät zuordnen und Betriebssystem erkennen oder bestätigen.
2. Lokalen Helfer gemäß tatsächlich unterstütztem Verfahren einrichten. Download, Ausführung und erwartete Rückmeldung verständlich erklären.
3. Projektordner zuordnen; vorhandene Konfiguration erhalten und notwendige Änderungen konkret benennen.
4. Verbindung und benötigte Fähigkeiten prüfen. Ein bloß kopierter Befehl gilt nicht als erfolgreicher Abschluss.

Falls ein Terminalbefehl erforderlich ist: erklären, welches Programm geöffnet wird, wo der Befehl hineingehört und woran Erfolg erkennbar ist. Die Oberfläche wartet auf ein tatsächliches Prüfergebnis. Kopierhilfe allein macht den Vorgang nicht anfängertauglich.

„Später fortsetzen“ ist auf jedem Schritt verfügbar. Codex wird erst beim ersten gewünschten KI-Auftrag eingerichtet. Es werden keine zusätzlichen Modell-APIs, Schlüssel oder Credits eingeführt. Jeder nutzt sein eigenes Konto; Projektmitgliedschaft gewährt keinen Zugriff auf die Anmeldung oder das Gerät des anderen.

Bei Abolimit: Auftrag mit nachvollziehbarem Zwischenstand unterbrechen, später fortsetzen oder manuell weiterarbeiten. Kein automatischer Anbieterwechsel.

## 9 Aufgabe als gemeinsamer Arbeitszusammenhang

### Aufbau der Aufgabenansicht

Oben: Titel, Projekt, Ziel, verantwortliche Person und Status. Direkt darunter „Nächster Schritt“ mit führender Aktion. Anschließend aktueller Arbeitsstand beziehungsweise Ergebnis und aufgabenbezogene Rückfragen. Verlauf und technische Herkunft sind aufklappbar.

Pflicht bei einer umsetzbaren Aufgabe: Titel, gewünschtes Ergebnis, verantwortliche Person. Vor der Übergabe zur Prüfung zusätzlich ein verständliches Abnahmekriterium und ein konkretes Ergebnis. Ein kurzer Aufgabenentwurf darf zunächst unvollständig bleiben und ist entsprechend markiert.

Eine offene Aufgabe hat eine verantwortliche Person. Wird sie neu zugewiesen, erhält diese eine Benachrichtigung. Die Übernahme einer bereits begonnenen Arbeit wird als ausdrückliche Übergabe behandelt, mit letztem Stand und offenen Punkten. Sie überträgt keine private Arbeitskopie oder Geräteberechtigung.

### Status und nächste Handlung

| Status | Bedeutung | Nächste typische Aktion |
| --- | --- | --- |
| Geplant | Auftrag vorhanden, Arbeit noch nicht begonnen | Aufgabe beginnen |
| In Arbeit | Eine Person bearbeitet den Auftrag | Arbeit fortsetzen |
| Zur Prüfung | Konkretes Ergebnis wartet auf benannte andere Person | Ergebnis prüfen |
| Erledigt | Vereinbartes Ergebnis angenommen oder reine Planungsaufgabe abgeschlossen | Ergebnis ansehen |

„Rückfrage offen“ und „Blockiert“ sind ergänzende Hinweise mit Grund und zuständiger Person, keine zweite konkurrierende Aufgabenliste. Bei einer Rückfrage bleibt sichtbar, wer antworten muss. „Zur Prüfung“ wird durch eine explizite Ergebnisübergabe erreicht, nicht durch eine beliebige Statusauswahl ohne Ergebnis.

### Mensch und KI

„Selbst bearbeiten“ öffnet die passende eigene Arbeit. „Mit Codex bearbeiten“ zeigt zuerst den konkreten Auftrag, erlaubten Umfang und das eigene ausführende Gerät. Erst „Auftrag starten“ löst die Ausführung aus.

Während der Ausführung: tatsächlicher Zustand, letzter Fortschritt, Rückfragen und „Stoppen“. „Stoppen angefragt“ ist vom bestätigten Ende zu unterscheiden. Wiederholen nach einem Fehler startet nicht unbemerkt eine zweite parallele Ausführung.

## 10 Wiederaufnahme und Zusammenarbeit

Nach Browserneustart findet der Nutzer dasselbe Projekt, die zugeordnete Aufgabe und die eigene Arbeitskopie wieder. Gespeicherte Änderungen und nur lokal vorhandene Entwürfe sind unterscheidbar. Gerätewechsel wird ausdrücklich benannt: Ein privater Entwurf auf Marcos Laptop ist nicht automatisch auf Markus' Gerät verfügbar.

Einladungen erfolgen innerhalb eines Projekts. Der Dialog nennt Projekt, Empfänger und Rolle. Für den ersten Umfang genügen „Mitarbeiten“ und „Ansehen und Feedback geben“; die tatsächliche technische Rechteabbildung muss vor Implementierung geprüft werden. Projektverwaltung verbleibt beim Verantwortlichen.

Einladungszustände: noch nicht erstellt, offen, angenommen, abgelaufen oder widerrufen. „Einladung erstellt“ darf nicht „E-Mail zugestellt“ bedeuten. Linkeinladung und E-Mail-Versand werden nur angeboten, wenn der jeweilige Übertragungsweg wirklich unterstützt wird.

Nach Annahme sieht Markus: Projektziel, aktuelle Etappe, seine Rolle und gegebenenfalls die konkrete Aufgabe. Er kann sofort lesen und Feedback geben. Eine eigene Geräteverbindung wird erst für eigene Ausführung verlangt.

Projektgespräche dürfen in Vorschläge münden. Erst „Als Entscheidung bestätigen“ erzeugt eine vereinbarte Entscheidung mit Autor und Zeitpunkt. „Aufgabe daraus erstellen“ verlinkt die Entscheidung; ein wiederholter Klick darf keine stillen Duplikate erzeugen.

Benachrichtigungen erscheinen für direkte Fragen, Zuweisungen, Prüfaufträge und Änderungen am eigenen Auftrag. Reine Aktivität erzeugt keinen Pflichtpunkt in „Für mich“. Ein gelesener Prüfauftrag bleibt dort, bis die Prüfung beantwortet oder zurückgezogen wurde.

## 11 Ergebnisse und Prüfung

Eine Ergebniskarte zeigt: Was wurde verändert? Von wem? Welcher Stand? Wie kann ich es ansehen? Was wurde geprüft? Was soll die andere Person beurteilen?

Bei Codeänderungen ist die Prüfung an einen konkreten Stand gebunden. Aktionen: „Änderungen anfordern“ mit begründetem Feedback oder „Ergebnis annehmen“. Der Autor nimmt sein eigenes Ergebnis im gemeinsamen Prüfablauf nicht selbst an.

Nach neuen Änderungen ist die alte Prüfung als überholt sichtbar und eine erneute Prüfung nötig. Bei Übernahme durch einen neuen Bearbeiter muss die prüfende Person erneut passend bestimmt werden.

Die Darstellung trennt:

- **Gespeichert:** Die Arbeit ist am angegebenen Ort erhalten.
- **Technisch geprüft:** Genannte Tests wurden für den angegebenen Stand ausgeführt.
- **Angenommen:** Die benannte Person hat genau diesen Stand beurteilt.
- **Übernommen:** Die Änderung wurde nachweislich in den gemeinsamen Zielstand integriert.
- **Veröffentlicht:** Der entsprechende Stand wurde nachweislich am angegebenen Ziel bereitgestellt.

Eine nicht erreichbare Vorschau bleibt mit Ursache und Alternative sichtbar. Ein Screenshot ersetzt keinen erfolgreich getesteten interaktiven Buchungsablauf. Fehlt ein aktueller Nachweis, steht „Ungeprüft“ statt eines grünen Erfolgszeichens.

## 12 Fehler und besondere Zustände

| Situation | Aussage an den Nutzer | Weiterer Weg |
| --- | --- | --- |
| Noch keine Aufgabe | „Euer Ziel steht. Legt jetzt den ersten Schritt fest.“ | Erste Aufgabe erstellen |
| Keine Suchtreffer | „Kein Projekt passt zu deiner Suche.“ | Suche ändern oder zurücksetzen |
| Gerät offline | „Dein Arbeitsgerät ist nicht erreichbar. Neue Ausführung ist gerade nicht möglich.“ | Verbindung erneut prüfen; Planung bleibt nutzbar |
| Speicherung fehlgeschlagen | „Deine letzte Eingabe wurde noch nicht gespeichert.“ | Eingabe erhalten, erneut versuchen, Kopie sichern |
| Gleichzeitige Änderung | „Markus hat diesen Stand inzwischen geändert.“ | Unterschiede zeigen; eigene Eingabe erhalten; keine stille Überschreibung |
| Einrichtung unvollständig | „Zum Bearbeiten fehlt noch die Projektverbindung.“ | Genau diesen Schritt fortsetzen |
| Test fehlgeschlagen | „Diese Prüfung ist fehlgeschlagen. Dein Arbeitsstand bleibt erhalten.“ | Konkrete Ursache ansehen, korrigieren, erneut prüfen |
| Ergebnis inzwischen geändert | „Die bisherige Rückmeldung gilt für einen älteren Stand.“ | Aktuellen Stand erneut prüfen |
| Einladung abgelaufen | „Diese Einladung ist nicht mehr gültig.“ | Neue Einladung beim Projektverantwortlichen anfordern |
| Keine Berechtigung | „Du kannst das Ergebnis ansehen, aber diese Aktion nicht ausführen.“ | Zuständige Person und erlaubte Alternative nennen |

Offene Zustände werden direkt bei der betroffenen Arbeit erklärt. Dauerhafte globale Warnbanner bleiben tatsächlichen übergreifenden Problemen vorbehalten.

## 13 Visuelle und sprachliche Gestaltung

Die vorhandene SCHMAQQ-Identität mit hellem Papiergrund, dunkler Typografie und grünen beziehungsweise korallfarbenen Akzenten wird weitergeführt. Farbe bezeichnet eine Funktion: Grün hebt die nächste Handlung hervor; Koralle lenkt auf nötige Aufmerksamkeit. Jeder Status hat zusätzlich verständlichen Text.

Inhaltspriorität: nächster Schritt vor Kennzahlen, Ergebnis vor technischem Verlauf, Projektziel vor Aktivitätsfeed. Fließtext als Richtwert 16 px, ergänzende Metadaten mindestens gut lesbar; keine wesentliche Information ausschließlich in winziger Monospace-Schrift.

Kontrastziel: mindestens 4,5:1 für normalen Text. Bedienelemente mit klarer Tastaturfokusanzeige, verständlichen Namen und ungefähr 44 × 44 px großen Zielflächen. Dialoge führen den Fokus hinein und nach dem Schließen zurück. Bewegungsreduktion wird berücksichtigt. Speicherung oder Fehler werden auch für Screenreader mitgeteilt, ohne ganze Seiten ständig neu vorzulesen.

Smartphone: primäre Handlung früh sichtbar, Navigation einklappbar, Aufgaben standardmäßig als Liste. Ein optionales Board darf innerhalb seines Bereichs horizontal scrollen; die ganze Seite nicht. Bei großer Schrift bleiben Inhalte und Schaltflächen erreichbar.

Lebendigkeit entsteht durch echte Personen, relevante Veränderungen, Ergebnisse und Fortschritt. Keine künstlichen Online-Punkte, dekorative Diagramme oder dauernd bewegten Elemente.

Bevorzugte Sprache: „Projekt starten“, „Arbeit fortsetzen“, „Ergebnis prüfen“, „Arbeitsgerät verbinden“. Technische Begriffe bleiben in Details exakt, damit Fehlersuche und Nachweise möglich sind.

## 14 Abnahme mit echten Nutzern

Zuerst werden die folgenden Situationen als statische Seitenfolgen samt Fehlerzuständen ausgearbeitet. Erst nach inhaltlicher Durchsicht folgt ein begrenzter Klickprototyp. Eine technische Umsetzung ist ein anschließender gesonderter Auftrag.

Für den Verständlichkeitstest erhält die Testperson nur ein Ziel, keine Klickanleitung. Beobachter protokollieren Suchwege, Fehlannahmen, Hilferufe und Abbrüche. Marco und Markus prüfen den Alltagsnutzen; für die Behauptung „anfängertauglich“ ist zusätzlich eine unbeteiligte Person ohne Studio-Vorwissen sinnvoll. Zwei Gründer mit Vorwissen ersetzen diesen Test nicht.

| Fall | Auftrag an die Testperson | Muss erkennbar gelingen |
| --- | --- | --- |
| Neuer Start | „Beginne eine einfache Buchungswebsite.“ | Ziel, erste Version und erste Aufgabe ohne mündliche Anleitung anlegen |
| Bestehendes Projekt | „Führe dieses vorhandene Testprojekt weiter.“ | Richtige Quelle erkennen; offene Prüfung verstehen; vorhandene Änderungen erhalten |
| Einladung | „Bitte gib Marco Feedback.“ | Projekt verstehen, Ergebnis öffnen, Rückmeldung ohne Geräteinstallation geben |
| Wiederaufnahme | „Mach nach der Pause weiter.“ | Richtige Aufgabe und letzten Stand innerhalb von 30 Sekunden finden |
| Einrichtung | „Bereite dein Gerät für diese Aufgabe vor.“ | Schritte verfolgen, tatsächlichen Erfolg erkennen, Unterbrechung fortsetzen |
| Offline | „Dein Arbeitsgerät ist jetzt ausgeschaltet.“ | Ausführungsgrenze verstehen und weiter planen können |
| Prüfung | „Beurteile Markus' Ergebnis.“ | Stand und Prüfumfang verstehen; Feedback korrekt zuordnen |
| Neue Version | „Das Ergebnis wurde nach deiner Prüfung verändert.“ | Erkennen, dass die alte Annahme nicht für den neuen Stand gilt |
| Doppelbearbeitung | „Ihr habt beide denselben Text geändert.“ | Eigene Eingabe erhalten; Konflikt bewusst lösen |
| Mobil | „Beantworte unterwegs eine Rückfrage.“ | Navigation und Kernaktion ohne abgeschnittene Inhalte erreichen |

Die 30 Sekunden sind ein vorgeschlagenes Abnahmeziel, kein gemessener Wert. Pro Fall werden Erfolg, benötigte Hilfe und Fehlannahmen erfasst. Kritische Kriterien: kein Datenverlust, keine Verwechslung von angenommen und veröffentlicht, keine Ausführung auf einem fremden Gerät. Ein kritischer Fehler verhindert die Abnahme des betroffenen Ablaufs.

## 15 Reihenfolge nach der Konzeptdurchsicht

1. Die hier beschriebenen Begriffe, Seiten und Nutzerwege inhaltlich prüfen. Offene Entscheidungen konkret am Ablauf klären.
2. Statische Seitenfolgen für Start, neues Projekt, bestehenden Bestand, Aufgabe, Einrichtung, Einladung und Ergebnisprüfung erstellen. Jeweils auch leeren, fehlerhaften und unterbrochenen Zustand zeigen.
3. Einen kleinen Klickprototyp nur für diese Strecken erstellen und mit echten Personen prüfen. Demo und echte Verbindung klar kennzeichnen.
4. Vor Umsetzung jede benötigte Fähigkeit gegen den aktuellen verbindlichen GitHub-Stand und gesondert gegen lokale Änderungen abgleichen. Vorhandene Funktion übernehmen, UX-Lücke schließen, fehlende Funktion separat planen.
5. Einen echten gemeinsamen Arbeitsdurchlauf mit begrenztem Projekt durchführen. Push, Merge, Deployment und Migration bleiben gesondert zu beauftragende Schritte.

Noch technisch zu klären sind insbesondere unterstützte Einladungswege und Rollen, der tatsächlich verfügbare Einrichtungsweg pro Betriebssystem, bestehende Ereignisdaten für Wiederaufnahme sowie die unterstützten Projektarten. Diese Punkte dürfen im Entwurf als Anforderungen erscheinen, aber nicht als vorhandene Fähigkeiten ausgegeben werden.

## 16 Quellen und Nachweis dieses Konzepts

Arbeitsauftrag: bestehendes Studio-Bedienkonzept für Marco und Markus ausarbeiten; keine Programmierung. Schreibumfang nur diese neue Unterlage im übergeordneten lokalen Arbeitsbereich. Abnahme dieser Arbeit: vollständige Wege, Zustände, Seitenstruktur, technische Grenzen und überprüfbare Nutzerkriterien. Aufwandgrenze: eine Konzeptfassung und eine redaktionelle Eigenprüfung; keine Implementierung, Installation oder externe Mutation.

Gelesene Originalquellen:

- Nutzerentscheidung in diesem Chat vom 24.10.2026: Empfehlung zum ersten Umfang für Marco und Markus angenommen.
- `C:/Users/hi/Downloads/05_INTERAKTIVE_VORSCHAU_B21.html`: Offline-Prototyp; im vorherigen Durchgang Quelltext geprüft.
- `C:/Users/hi/Documents/ChatGPT/SCHMAQQ/schmaqq-workspace/docs/PRODUCT_VISION.md`: Plattformbild und erster Zwei-Personen-Umfang; Dokument selbst als Architekturvorschlag gekennzeichnet.
- `C:/Users/hi/Documents/ChatGPT/SCHMAQQ/schmaqq-workspace/docs/GETTING_TO_DAILY_USE.md`: technischer Pilot versus persönliche Alltagstauglichkeit.
- `C:/Users/hi/Documents/ChatGPT/SCHMAQQ/schmaqq-workspace/docs/STATUS.json` und `docs/HANDOFF.md`: lokale Zustands- und Übergabeberichte; auszugsweise neu gelesen, keine Wiederholung ihrer Testnachweise.
- Arbeitsbasis: `AGENTS.md`, `vault/00_START.md`, `vault/01_Projekte/SCHMAQQ_Studio.md` unter `C:/KI/SCHMAQQ/SCHMAQQ_Arbeitsbasis_V1`.

Lokaler Nachweis am 24.10.2026: HEAD des ursprünglichen Studio-Checkouts `9696b2d582220b6ec4ff1d70a3a5e740533c54a3`; zahlreiche geänderte und unversionierte Dateien, darunter STATUS und HANDOFF. Diese lokalen Berichte sind nicht vollständig durch den HEAD repräsentiert. GitHub und Server wurden in diesem Konzeptauftrag nicht neu geprüft. Deshalb enthält dieses Dokument keine Aussage zum aktuell ausgerollten Funktionsstand. Die ältere Vault-Projektkarte und die jüngeren lokalen Berichte dürfen nicht zu einem vermeintlich verifizierten Live-Stand zusammengezogen werden.

Selbst ausgeführt: lokale Textlektüre, Git-Status und HEAD-Abfrage mit nur befehlsbezogener Verzeichnisfreigabe, Konzept erstellt und auf inhaltliche Vollständigkeit geprüft. Keine Anwendungs-, Browser- oder Nutzertests in diesem Auftrag; frühere PASS-Angaben bleiben gelesene Berichte. Keine Repositorydatei oder globale Git-Einstellung geändert.

### Vorschlag für die Arbeitsbasis

Datum: 24.10.2026. Neue bestätigte Entscheidung: Erster UX-Umfang konzentriert sich auf Marco und Markus; Anfängerführung bleibt Ziel. Konzeptdatei und oben genannter lokaler Arbeitsstand sind die Quellen. Ausgearbeitet wurden Nutzerwege, Informationsstruktur, Einrichtung, Wiederaufnahme, Zusammenarbeit und Abnahmekriterien. Details sind Entwurf, noch keine getestete Produktoberfläche. Offen: inhaltliche Durchsicht, aktuelle technische Zuordnung und Nutzertest. Nächster Schritt: statische Seitenfolgen nach Konzeptdurchsicht, weiterhin vor Implementierung.

Die Arbeitsbasis liegt außerhalb der erlaubten Schreibpfade. Dieser Vorschlag wurde deshalb hier erhalten und nicht in `vault/05_Eingang/` abgelegt. Vorhandene Projektakten und Regeln wurden nicht geändert.
